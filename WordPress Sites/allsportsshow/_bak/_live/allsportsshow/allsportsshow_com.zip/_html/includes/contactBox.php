<div id="Contact_Box" class="clearfix">

	<p class="Address_Box">
        <strong>Address:</strong><br />
       n/a
    </p>
    <div>
        <p class="Phone_Box">
<strong>Phone:</strong>123-456-7890
        </p>
        <p class="Email_Box">
            <strong>Email:</strong><br />
            <a href="mailto:email@email.com" rel="external">email@email.com</a>
        </p>
    </div>

</div>
 
 
 