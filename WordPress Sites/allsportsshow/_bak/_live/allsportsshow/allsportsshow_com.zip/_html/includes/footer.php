<?php echo date("Y"); ?>
<!--- END FOOTER -->
<noscript>
  <p class="nojavascript">Your browser does not support JavaScript. Please change your browser settings to enable Javascript.</p>
  </noscript>  
</body>
</html>