    <li <?php isActiveMenu("index.php"); ?>><a href="index.php">Home</a></li>

