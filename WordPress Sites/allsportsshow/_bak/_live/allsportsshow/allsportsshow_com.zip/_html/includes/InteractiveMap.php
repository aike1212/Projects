<!-- This is the msn Maps Script for Contact Page, Simply Set the Varibles below and Server Side include on the contact page.  -->

<?php $mapWidthVar = 500;
	$mapHeightVar = 500; ?>

<div id='myMap' style="position:relative; margin:0 auto; width:<?php echo $mapWidthVar?>px; height:<?php echo $mapHeightVar?>px; " class="map-border"></div>