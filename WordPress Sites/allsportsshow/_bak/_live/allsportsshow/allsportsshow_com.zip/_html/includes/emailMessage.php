<div id="Email_Message" style="width:500px;">
	<h5>Thank You!</h5>
	<p style="width:500px; margin:0; padding:0;">Below is the message you sent us. Please allow 24 hours for our response.</p>
</div>