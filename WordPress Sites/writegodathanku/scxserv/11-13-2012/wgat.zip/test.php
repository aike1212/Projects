require( dirname(__FILE__) . '/wp-load.php' );
require_once( ABSPATH . 'wp-includes/plugin.php');
require_once( ABSPATH . 'wp-includes/pluggable.php');


$password = 'lito';


/**///------------------------------------------------------/**/
/**/   echo $hashedpass = wp_hash_password($password); /**/
/**/   /**/
/**/   echo "<br /><br />"; /**/
/**/   echo wp_check_password($password,$hashedpass, ""); /**/
/**/   /**/
/**/   echo "<br /><br />"; /**/
/**///------------------------------------------------------/**/