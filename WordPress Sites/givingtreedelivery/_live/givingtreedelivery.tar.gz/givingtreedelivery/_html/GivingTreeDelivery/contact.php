<?php include('includes/meta.php'); ?>
    <div id="Main_Layout">
    
        <div id="Content_Container" class="clearfix">
        
            <div id="Main_Content">

                <h1>Contact Form</h1>
				<?php include('includes/contactForm.php'); ?>
    
            </div>
            
            <?php include('includes/sidebar.php'); ?>
        
        </div>
        
        <?php include('includes/header.php'); ?>
    
    </div>
<?php include('includes/footer.php'); ?>