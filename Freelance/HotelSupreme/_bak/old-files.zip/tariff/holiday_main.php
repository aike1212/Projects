<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd" >
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" >
 	<head>
 		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1" />
 		<meta name="keywords" content="Hotel Supreme, Hotel Supreme Convention Plaza, Baguio City Hotels, Hotels" />
 		<meta name="description" content="Hotel Supreme Convention Plaza" />
</head>

 <BODY background="../hs/wallpaper.gif">

<?
include 'connect.php';

$query="SELECT * FROM holiday_main";
$result=mysql_query($query);

$num=mysql_numrows($result);

mysql_close();



$i=0;
while ($i < $num) {

$period=mysql_result($result,$i,"period");
$doublephp=mysql_result($result,$i,"doublephp");
$doubleusd=mysql_result($result,$i,"doubleusd");
$familyphp=mysql_result($result,$i,"familyphp");
$familyusd=mysql_result($result,$i,"familyusd");
$juniorphp=mysql_result($result,$i,"juniorphp");
$juniorusd=mysql_result($result,$i,"juniorusd");
$executivephp=mysql_result($result,$i,"executivephp");
$executiveusd=mysql_result($result,$i,"executiveusd");
$washupphp=mysql_result($result,$i,"washupphp");
$washupusd=mysql_result($result,$i,"washupusd");
$bedphp=mysql_result($result,$i,"bedphp");
$bedusd=mysql_result($result,$i,"bedusd");
$personphp=mysql_result($result,$i,"personphp");
$personusd=mysql_result($result,$i,"personusd");



$i++;
}

?>

<center>
 <table border = 2  bordercolor="#000000" >
	<tr> <td width="393" height="300">
	<table>
	<tr><td align="center" width="385"><strong><font size="5" face="Geneva, Arial, Helvetica, sans-serif">Hotel Supreme Convention Plaza <br> 
	HOLIDAY Tariff Rates</font></strong></td>
	</tr>
	<tr>
	</tr>
    <tr>
	<tr><td align="center" height="28"><strong><font face="Geneva, Arial, Helvetica, sans-serif"><? echo $period ?></font></strong></td>
	</tr>
	<tr>
	<tr>
      	</table>
	<table border = 1>
	<font face="verdana" size=1>
		<tr align="left">
			<font face = "Verdana" size=1>
			<td width="145"><b>TYPE OF ROOM</b></td>
			<td width="85"><b>CAPACITY</b></td>
			<td width="70"><b>PHP</b></td>
            <td width="70"><b>USD</b></td>
			</font>		</tr>
		</font>
	<tr>
			<td align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">DOUBLE DE LUXE</font></td>
			<td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">2 persons</font></td>
			<td Align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><? echo $doublephp ?></font></td>
            <td Align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><? echo $doubleusd ?></font></td>
		</tr>
	<font face="verdana" size=1>		</font>
	<tr>
			<td align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">FAMILY DE LUXE</font></td>
			<td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">3-4 persons</font></td>
			<td Align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><? echo $familyphp ?></font></td>
            <td Align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><? echo $familyusd ?></font></td>
		</tr>
	<font face="verdana" size=1>		</font>
	<tr>
			<td><div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">JUNIOR SUITE</font></div></td>
			<td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">2 persons</font></td>
			<td Align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><? echo $juniorphp ?></font></td>
            <td Align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><? echo $juniorusd ?></font></td>
		</tr>
	<font face="verdana" size=1>		</font>
	<tr>
			<td height="19"><div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">EXECUTIVE SUITE</font></div></td>
			<td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">2 persons</font></td>
			<td Align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><? echo $executivephp ?></font></td>
            <td Align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><? echo $executiveusd ?></font></td>
		</tr>
		<tr>
			<td><div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">WASH UP</font></div></td>
			<td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
			<td Align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><? echo $washupphp ?></td>
            <td Align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><? echo $washupusd ?></font></td>
		</tr>
	<font face="verdana" size=1>		</font>
	<tr>
			<td><div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">EXTRA BED</font></div></td>
			<td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
			<td Align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><? echo $bedphp ?></font></td>
            <td Align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><? echo $bedusd ?></font></td>
		</tr>
	<font face="verdana" size=1>		</font>
	<tr>
			<td height="23"><div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">EXTRA PERSON</font></div></td>
			<td><font size="1" face="Verdana, Arial, Helvetica, sans-serif">&nbsp;</font></td>
			<td Align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><? echo $personphp ?></font></td>
            <td Align="right"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"><? echo $personusd ?></font></td>
		</tr>
	<font face="verdana" size=1>	  </font>
	</table>
	
	<tr><td>
		<table width="393">
		  <tr><td width="385">
		<ul>
		    <font size="2" face="verdana"><i><b>
		    </font><font face="verdana">
		    <li><font size="2">
		      <div align="left">Complimentary American/Filipino/Continental Breakfast</div>
		      </font></li>
		    <li>
		      <div align="left"><font size="2">Tariff rates are inclusive of government tax and service charge.</font></div>
		      </li>
		    <li>
		      <div align="left"><font size="2">Check-in: 1:00 PM, Check-out 12:00 NOON</font></div>
		      </li>
		    <li>
		      <div align="left"><font size="2">Confirmed rooms will be held until 5:00 PM unless guaranteed by a first night deposit.</font></div>
		      </li>
		    <li>
		      <div align="left"><font size="2">Children age 12 years and below are extended complimentary accomodation when sharing rooms & bed with parents.</font></div>
		      </li>
		    <li>
		      <div align="left"><font size="2">Bath tub, aircondition, telephone (NDD/IDD), cable television and radio are standard amenities on all types of rooms.</font></div>
		      </li>
		    <li>
		      <div align="left"><font size="2">Executive Suites are equipped with Spa/Jacuzzi and 25" color television. </font></div>
		      <li>
		        <div align="left"><font size="2">Corporate rates; conference; seminars and convention packages; wedding package and birthday/debut packages are available upon request.</font></div>
		        </Li>
		    <li>
		      <div align="left"><font size="2">Rates are subject to change without prior notice.</font></div>
		      <font size="2"></font></li>
		    <font size="2"><i><b>
			</font></font>
		</ul>
	  </td></tr></table>
	</td></tr>
	<tr><td>
		<center>
			<font face="verdana" size =2 >
			<p>113 Magsaysay Avenue, 2006 Baguio City, Philippines<br>
			Tel: +63(74)443-2011 to 18 Fax: +63(74)442-2855<br>
			Manila Direct Line: 250-6025<br>
			Email1: hotelsupreme@skyinet.net<br>
			Email2: contact_us@hotelsupreme.com.ph<br>
			<a href="http://www.hotelsupreme.com.p">http://www.hotelsupreme.com.ph</a><br>
			<p></font>
		</center>
	</td></tr>
</table>
</center>
</body>
</html>