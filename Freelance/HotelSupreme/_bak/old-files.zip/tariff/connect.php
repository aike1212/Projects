<?
$username="hsupreme_stone";
$password="64853152";
$database="hsupreme_tariff";

mysql_connect(localhost,$username,$password);
@mysql_select_db($database) or die( "Unable to select database");

?>