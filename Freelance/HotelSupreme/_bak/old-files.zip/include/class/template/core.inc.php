<?php
/**
 * Open-Realty
 *
 * Open-Realty is free software; you can redistribute it and/or modify
 * it under the terms of the Open-Realty License as published by
 * Transparent Technologies; either version 1 of the License, or
 * (at your option) any later version.
 *
 * Open-Realty is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * Open-Realty License for more details.
 * http://www.open-realty.org/license_info.html
 *
 * You should have received a copy of the Open-Realty License
 * along with Open-Realty; if not, write to Transparent Technologies
 * RR1 Box 162C, Kingsley, PA  18826  USA
 *
 * @author Ryan C. Bonham <ryan@transparent-tech.com>
 * @copyright Transparent Technologies 2004
 * @link http://www.open-realty.org Open-Realty Project
 * @link http://www.transparent-tech.com Transparent Technologies
 * @link http://www.open-realty.org/license_info.html Open-Realty License
 */

class page {
	var $page;
	function load_js()
	{
		global $lang, $jscript, $config;
		$display = '';
		$display .= '<script type="text/javascript">' . "\r\n";
		$display .= '<!--' . "\r\n";
		$display .= 'function confirmDelete()' . "\r\n";
		$display .= '{' . "\r\n";
		$display .= 'var agree=confirm("' . $lang['are_you_sure_you_want_to_delete'] . '");' . "\r\n";
		$display .= 'if (agree)' . "\r\n";
		$display .= 'return true ;' . "\r\n";
		$display .= 'else' . "\r\n";
		$display .= 'return false ;' . "\r\n";
		$display .= '}' . "\r\n";
		$display .= '//-->' . "\r\n";
		$display .= '</script>' . "\r\n";
		$display .= '<script type="text/javascript">' . "\r\n";
		$display .= '<!--' . "\r\n";
		$display .= 'function open_window(url)' . "\r\n";
		$display .= '{' . "\r\n";
		$display .= 'cwin = window.open(url,"attach","width=350,height=400,toolbar=no,resizable=yes");' . "\r\n";
		$display .= '}' . "\r\n";
		$display .= 'function ptoutput(theText)' . "\r\n";
		$display .= '{' . "\r\n";
		$display .= 'document.write(theText);' . "\r\n";
		$display .= '}' . "\r\n";
		$display .= '//-->' . "\r\n";
		$display .= '</script>' . "\r\n";
		$display .= $jscript;
		return $display;
	}
	function auto_replace_tags($section = '')
	{
		if ($section == '') {
			$section = $this->page;
		}
		preg_match_all("/{(?!lang)(.*?)}/i", $section, $tags_found);
		$tags_found = $tags_found[1];
		$tags_special = array('content', 'site_title');
		$tags_found = array_diff($tags_found, $tags_special);
		foreach ($tags_found as $x => $y) {
			if (strpos($y, 'load_') === 0) {
				unset($tags_found[$x]);
			}
		}
		$this->replace_tags($tags_found);
	}
	function get_addon_template_field_list($addons)
	{
		global $config;
		$template_list = array();
		foreach ($addons as $addon) {
			$addon_file = $config['basepath'] . '/addons/' . $addon . '/addon.inc.php';
			if (file_exists($addon_file)) {
				include_once ($addon_file);
				$function_name = $addon . '_load_template';
				$addon_fields = $function_name();
				if (is_array($addon_fields)) {
					$template_list = array_merge($template_list, $addon_fields);
				}
			}
		}
		return $template_list;
	}
	function load_addons()
	{
		global $lang, $config;
		// Get Addon List
		$dir = 0;
		$options = array();
		if ($handle = opendir($config['basepath'] . '/addons')) {
			while (false !== ($file = readdir($handle))) {
				if ($file != "." && $file != ".." && $file != "CVS" && $file != ".svn") {
					if (is_dir($config['basepath'] . '/addons/' . $file)) {
						$options[$file] = $file;
						$dir++;
					}
				}
			}
			closedir($handle);
		}
		return $options;
	}
	// This function should be called first, it checks that the page exsists and sets up the page variable for the other functions
	function load_page($template = '', $parse = true)
	{
		if (file_exists($template)) {
			if ($parse == false) {
				$this->page = file_get_contents($template);
			} else {
				$this->page = $this->parse($template);
			}
		} else {
			die('Template file ' . $template . ' not found.');
		}
	}
	// This function allows us to parse the file allowing us to have php directives
	function parse($file)
	{
		ob_start();
		include($file);
		$buffer = ob_get_contents();
		ob_end_clean();
		return $buffer;
	}
	function get_template_section_row($section_name)
	{
		if (!empty($section_name)) {
			$section = '/{' . $section_name . ' repeat="([0-9]{1,3})"}(.*?){\/' . $section_name . '}/is';
			$section_results = array();
			preg_match($section, $this->page, $section_results);
			if (isset($section_results[1])) {
				return array($section_results[2], $section_results[1]);
			}
		}
	}
	function get_template_section($section_name)
	{
		if (!empty($section_name)) {
			$section = '/{' . $section_name . '}(.*?){\/' . $section_name . '}/is';
			$section_results = array();
			preg_match($section, $this->page, $section_results);
			if (isset($section_results[1])) {
				return $section_results[1];
			}
			return false;
		}
	}
	function cleanup_template_block($block, $section)
	{
		$section = str_replace('{' . $block . '_block}', '', $section);
		$section = str_replace('{/' . $block . '_block}', '', $section);
		return $section;
	}
	function remove_template_block($block, $section)
	{
		$find_block = '/{' . $block . '_block}(.*?){\/' . $block . '_block}/is';
		$section = preg_replace($find_block, '', $section);
		return $section;
	}
	function replace_tag($tag, $replacement)
	{
		$this->page = str_replace('{' . $tag . '}', $replacement, $this->page);
	}
	function parse_template_section($section_as_variable, $field, $value)
	{
		$section_as_variable = str_replace('{' . $field . '}', $value, $section_as_variable);
		$section_as_variable = $this->cleanup_template_block($field, $section_as_variable);
		return $section_as_variable;
	}
	function replace_template_section($section_name, $replacement, $page = '')
	{
		$section = '/{' . $section_name . '}(.*?){\/' . $section_name . '}/is';
		$replacement = str_replace('$', '\$', $replacement);
		if ($page == '') {
			$this->page = preg_replace("$section", "$replacement", $this->page);
		} else {
			$page = preg_replace("$section", "$replacement", $page);
			return $page;
		}
	}
	function replace_template_section_row($section_name, $replacement)
	{
		$section = '/{' . $section_name . ' (.*?)}(.*?){\/' . $section_name . '}/is';
		$replacement = str_replace('$', '\$', $replacement);
		$this->page = preg_replace("$section", "$replacement", $this->page);
	}
	/**
	 * This function is used to cleanup any {field_#} tags on the search result page that were not filled with data. It should be run after every data row.
	 *
	 * @param string $section Should contain the dataset section of the template that has been built so far.
	 * @return string Returns the $section that was passed to it minus all {field_#} tags.
	 */
	function cleanup_fields($section)
	{
		$section = preg_replace('/{field_(.*?)}/', '', $section);
		return $section;
	}
	function output_page()
	{
		print $this->page;
	}
	// This function returns the results for sub templates
	function return_page()
	{
		return $this->page;
	}
	function replace_permission_tags()
	{
		global $config;
		require_once($config['basepath'] . '/include/login.inc.php');
		$login = new login();
		// Check for tags: Admin, Agent, canEditForms, canViewLogs, editpages, havevtours
		$login_status = $login->verify_priv('Agent');
		if ($login_status !== true) {
			// Use pregreplace to removed {check_agent} tags and content between them
			$this->page = preg_replace('/{check_agent}(.*?){\/check_agent}/is', '', $this->page);
			$this->page = str_replace('{!check_agent}', '', $this->page);
			$this->page = str_replace('{/!check_agent}', '', $this->page);
		} else {
			// Use strreplace to remove {check_agent} tags and leave the content.
			$this->page = preg_replace('/{!check_agent}(.*?){\/!check_agent}/is', '', $this->page);
			$this->page = str_replace('{check_agent}', '', $this->page);
			$this->page = str_replace('{/check_agent}', '', $this->page);
		}
		$login_status = $login->verify_priv('Member');
		if ($login_status !== true) {
			// Use pregreplace to removed {check_agent} tags and content between them
			$this->page = preg_replace('/{check_member}(.*?){\/check_member}/is', '', $this->page);
			$this->page = str_replace('{!check_member}', '', $this->page);
			$this->page = str_replace('{/!check_member}', '', $this->page);
			$this->page = str_replace('{check_guest}', '', $this->page);
			$this->page = str_replace('{/check_guest}', '', $this->page);
		} else {
			// Use strreplace to remove {check_agent} tags and leave the content.
			$this->page = preg_replace('/{!check_member}(.*?){\/!check_member}/is', '', $this->page);
			$this->page = str_replace('{check_member}', '', $this->page);
			$this->page = str_replace('{/check_member}', '', $this->page);
			$this->page = preg_replace('/{check_guest}(.*?){\/check_guest}/is', '', $this->page);
		}
		$login_status = $login->verify_priv('Admin');
		if ($login_status !== true) {
			// Use pregreplace to removed {check_agent} tags and content between them
			$this->page = preg_replace('/{check_moderate_listings}(.*?){\/check_moderate_listings}/is', '', $this->page);
			$this->page = str_replace('{!check_moderate_listings}', '', $this->page);
			$this->page = str_replace('{/!check_moderate_listings}', '', $this->page);
			$this->page = str_replace('{!check_admin}', '', $this->page);
			$this->page = str_replace('{/!check_admin}', '', $this->page);
			$this->page = preg_replace('/{check_admin}(.*?){\/check_admin}/is', '', $this->page);
		} else {
			if ($config['moderate_listings'] === "1") {
				$this->page = str_replace('{check_moderate_listings}', '', $this->page);
				$this->page = str_replace('{/check_moderate_listings}', '', $this->page);
				$this->page = preg_replace('/{!check_moderate_listings}(.*?){\/!check_moderate_listings}/is', '', $this->page);
			} else {
				$this->page = str_replace('{!check_moderate_listings}', '', $this->page);
				$this->page = str_replace('{/!check_moderate_listings}', '', $this->page);
				$this->page = preg_replace('/{check_moderate_listings}(.*?){\/check_moderate_listings}/is', '', $this->page);
			}
			// Use strreplace to remove {check_agent} tags and leave the content.
			$this->page = str_replace('{check_admin}', '', $this->page);
			$this->page = str_replace('{/check_admin}', '', $this->page);
			$this->page = preg_replace('/{!check_admin}(.*?){\/!check_admin}/is', '', $this->page);
		}
		$login_status = $login->verify_priv('edit_site_config');
		if ($login_status !== true) {
			$this->page = preg_replace('/{check_edit_site_config}(.*?){\/check_edit_site_config}/is', '', $this->page);
			$this->page = str_replace('{!check_edit_site_config}', '', $this->page);
			$this->page = str_replace('{/!check_edit_site_config}', '', $this->page);
		} else {
			$this->page = str_replace('{check_edit_site_config}', '', $this->page);
			$this->page = str_replace('{/check_edit_site_config}', '', $this->page);
			$this->page = preg_replace('/{!check_edit_site_config}(.*?){\/!check_edit_site_config}/is', '', $this->page);
		}
		$login_status = $login->verify_priv('edit_member_template');
		if ($login_status !== true) {
			$this->page = preg_replace('/{check_edit_member_template}(.*?){\/check_edit_member_template}/is', '', $this->page);
			$this->page = str_replace('{!check_edit_member_template}', '', $this->page);
			$this->page = str_replace('{/!check_edit_member_template}', '', $this->page);
		} else {
			$this->page = str_replace('{check_edit_member_template}', '', $this->page);
			$this->page = str_replace('{/check_edit_member_template}', '', $this->page);
			$this->page = preg_replace('/{!check_edit_member_template}(.*?){\/!check_edit_member_template}/is', '', $this->page);
		}
		$login_status = $login->verify_priv('edit_agent_template');
		if ($login_status !== true) {
			$this->page = preg_replace('/{check_edit_agent_template}(.*?){\/check_edit_agent_template}/is', '', $this->page);
			$this->page = str_replace('{!check_edit_agent_template}', '', $this->page);
			$this->page = str_replace('{/!check_edit_agent_template}', '', $this->page);
		} else {
			$this->page = str_replace('{check_edit_agent_template}', '', $this->page);
			$this->page = str_replace('{/check_edit_agent_template}', '', $this->page);
			$this->page = preg_replace('/{!check_edit_agent_template}(.*?){\/!check_edit_agent_template}/is', '', $this->page);
		}
		$login_status = $login->verify_priv('edit_listing_template');
		if ($login_status !== true) {
			$this->page = preg_replace('/{check_edit_listing_template}(.*?){\/check_edit_listing_template}/is', '', $this->page);
			$this->page = str_replace('{!check_edit_listing_template}', '', $this->page);
			$this->page = str_replace('{/!check_edit_listing_template}', '', $this->page);
		} else {
			$this->page = str_replace('{check_edit_listing_template}', '', $this->page);
			$this->page = str_replace('{/check_edit_listing_template}', '', $this->page);
			$this->page = preg_replace('/{!check_edit_listing_template}(.*?){\/!check_edit_listing_template}/is', '', $this->page);
		}
		$login_status = $login->verify_priv('canViewLogs');
		if ($login_status !== true) {
			// Use pregreplace to removed {check_agent} tags and content between them
			$this->page = preg_replace('/{check_view_logs}(.*?){\/check_view_logs}/is', '', $this->page);
			$this->page = str_replace('{!check_view_logs}', '', $this->page);
			$this->page = str_replace('{/!check_view_logs}', '', $this->page);
		} else {
			$this->page = preg_replace('/{!check_view_logs}(.*?){\/!check_view_logs}/is', '', $this->page);
			// Use strreplace to remove {check_agent} tags and leave the content.
			$this->page = str_replace('{check_view_logs}', '', $this->page);
			$this->page = str_replace('{/check_view_logs}', '', $this->page);
		}
		$login_status = $login->verify_priv('editpages');
		if ($login_status !== true) {
			// Use pregreplace to removed {check_agent} tags and content between them
			$this->page = preg_replace('/{check_edit_pages}(.*?){\/check_edit_pages}/is', '', $this->page);
			$this->page = str_replace('{!check_edit_pages}', '', $this->page);
			$this->page = str_replace('{/!check_edit_pages}', '', $this->page);
		} else {
			// Use strreplace to remove {check_agent} tags and leave the content.
			$this->page = str_replace('{check_edit_pages}', '', $this->page);
			$this->page = str_replace('{/check_edit_pages}', '', $this->page);
			$this->page = preg_replace('/{!check_edit_pages}(.*?){\/!check_edit_pages}/is', '', $this->page);
		}
		$login_status = $login->verify_priv('edit_all_listings');
		if ($login_status !== true) {
			// Use pregreplace to removed {check_agent} tags and content between them
			$this->page = preg_replace('/{check_edit_all_listings}(.*?){\/check_edit_all_listings}/is', '', $this->page);
			$this->page = str_replace('{!check_edit_all_listings}', '', $this->page);
			$this->page = str_replace('{/!check_edit_all_listings}', '', $this->page);
		} else {
			// Use strreplace to remove {check_agent} tags and leave the content.
			$this->page = str_replace('{check_edit_all_listings}', '', $this->page);
			$this->page = str_replace('{/check_edit_all_listings}', '', $this->page);
			$this->page = preg_replace('/{!check_edit_all_listings}(.*?){\/!check_edit_all_listings}/is', '', $this->page);
		}
		$login_status = $login->verify_priv('edit_all_users');
		if ($login_status !== true) {
			// Use pregreplace to removed {check_agent} tags and content between them
			$this->page = preg_replace('/{check_edit_all_users}(.*?){\/check_edit_all_users}/is', '', $this->page);
			$this->page = str_replace('{!check_edit_all_users}', '', $this->page);
			$this->page = str_replace('{/!check_edit_all_users}', '', $this->page);
		} else {
			// Use strreplace to remove {check_agent} tags and leave the content.
			$this->page = str_replace('{check_edit_all_users}', '', $this->page);
			$this->page = str_replace('{/check_edit_all_users}', '', $this->page);
			$this->page = preg_replace('/{!check_edit_all_users}(.*?){\/!check_edit_all_users}/is', '', $this->page);
		}
		$login_status = $login->verify_priv('edit_property_classes');
		if ($login_status !== true) {
			// Use pregreplace to removed {check_agent} tags and content between them
			$this->page = preg_replace('/{check_edit_listing_classes}(.*?){\/check_edit_listing_classes}/is', '', $this->page);
			$this->page = str_replace('{!check_edit_listing_classes}', '', $this->page);
			$this->page = str_replace('{/!check_edit_listing_classes}', '', $this->page);
		} else {
			// Use strreplace to remove {check_agent} tags and leave the content.
			$this->page = str_replace('{check_edit_listing_classes}', '', $this->page);
			$this->page = str_replace('{/check_edit_listing_classes}', '', $this->page);
			$this->page = preg_replace('/{!check_edit_listing_classes}(.*?){\/!check_edit_listing_classes}/is', '', $this->page);
		}
		$login_status = $login->verify_priv('havevtours');
		if ($login_status !== true) {
			// Use pregreplace to removed {check_agent} tags and content between them
			$this->page = preg_replace('/{check_have_vtours}(.*?){\/check_have_vtours}/is', '', $this->page);
			$this->page = str_replace('{!check_have_vtours}', '', $this->page);
			$this->page = str_replace('{/!check_have_vtours}', '', $this->page);
		} else {
			// Use strreplace to remove {check_agent} tags and leave the content.
			$this->page = preg_replace('/{!check_have_vtours}(.*?){\/!check_have_vtours}/is', '', $this->page);
			$this->page = str_replace('{check_have_vtours}', '', $this->page);
			$this->page = str_replace('{/check_have_vtours}', '', $this->page);
		}
		if (isset($_GET['printer_friendly']) && $_GET['printer_friendly'] == 'yes') {
			$this->page = preg_replace('/{hide_printer_friendly}(.*?){\/hide_printer_friendly}/is', '', $this->page);
			$this->page = str_replace('{show_printer_friendly}', '', $this->page);
			$this->page = str_replace('{/show_printer_friendly}', '', $this->page);
		} else {
			$this->page = preg_replace('/{show_printer_friendly}(.*?){\/show_printer_friendly}/is', '', $this->page);
			$this->page = str_replace('{hide_printer_friendly}', '', $this->page);
			$this->page = str_replace('{/hide_printer_friendly}', '', $this->page);
		}
	}
	function replace_urls()
	{
		global $config;
		if ($config['url_style'] == '1') {
			$this->page = str_replace('{url_index}', $config['baseurl'] . '/index.php', $this->page);
			$this->page = str_replace('{url_search}', $config['baseurl'] . '/index.php?action=searchpage', $this->page);
			$this->page = str_replace('{url_search_rental}', $config['baseurl'] . '/index.php?action=search_step_2&amp;pclass[]=5', $this->page);
			$this->page = str_replace('{url_search_results}', $config['baseurl'] . '/index.php?action=searchresults', $this->page);
			$this->page = str_replace('{url_view_agents}', $config['baseurl'] . '/index.php?action=view_users', $this->page);
			$this->page = str_replace('{url_view_favorites}', $config['baseurl'] . '/index.php?action=view_favorites', $this->page);
			$this->page = str_replace('{url_view_calculator}', $config['baseurl'] . '/index.php?action=calculator&amp;popup=yes', $this->page);
			$this->page = str_replace('{url_view_saved_searches}', $config['baseurl'] . '/index.php?action=view_saved_searches', $this->page);
			$this->page = preg_replace('/{page_link_(.*?)}/is', $config['baseurl'] . '/index.php?action=page_display&amp;PageID=$1', $this->page);
			$this->page = str_replace('{url_logout}', $config['baseurl'] . '/index.php?action=logout', $this->page);
			$this->page = str_replace('{url_member_signup}', $config['baseurl'] . '/index.php?action=signup&amp;type=member', $this->page);
			$this->page = str_replace('{url_agent_signup}', $config['baseurl'] . '/index.php?action=signup&amp;type=agent', $this->page);
			$this->page = str_replace('{url_member_login}', $config['baseurl'] . '/index.php?action=member_login', $this->page);
			$this->page = str_replace('{url_agent_login}', $config['baseurl'] . '/admin/index.php', $this->page);
			if (isset($_SESSION['userID'])) {
				$this->page = str_replace('{url_edit_profile}', $config['baseurl'] . '/index.php?action=edit_profile&amp;user_id=' . $_SESSION['userID'], $this->page);
			}
		} else {
			$this->page = str_replace('{url_index}', $config['baseurl'] . '/index.html', $this->page);
			$this->page = str_replace('{url_search}', $config['baseurl'] . '/search.html', $this->page);
			$this->page = str_replace('{url_search_rental}', $config['baseurl'] . '/rental_search.html', $this->page);
			$this->page = str_replace('{url_search_results}', $config['baseurl'] . '/searchresults.html', $this->page);
			$this->page = str_replace('{url_view_agents}', $config['baseurl'] . '/agents.html', $this->page);
			$this->page = str_replace('{url_view_favorites}', $config['baseurl'] . '/view_favorites.html', $this->page);
			$this->page = str_replace('{url_view_calculator}', $config['baseurl'] . '/calculator.html', $this->page);
			$this->page = str_replace('{url_view_saved_searches}', $config['baseurl'] . '/saved_searches.html', $this->page);
			$this->page = preg_replace_callback('/{page_link_(.*?)}/is', create_function('$matches',
					'global $config; require_once($config[\'basepath\'].\'/include/page_display.inc.php\');
					$title = page_display::get_page_title($matches[1]);
					return $config[\'baseurl\'].\'/page-\'.urlencode($title).\'-\'.$matches[1].\'.html\';'), $this->page);
			$this->page = str_replace('{url_logout}', $config['baseurl'] . '/logout.html', $this->page);
			$this->page = str_replace('{url_member_signup}', $config['baseurl'] . '/member_signup.html', $this->page);
			$this->page = str_replace('{url_agent_signup}', $config['baseurl'] . '/agent_signup.html', $this->page);
			$this->page = str_replace('{url_member_login}', $config['baseurl'] . '/member_login.html', $this->page);
			$this->page = str_replace('{url_agent_login}', $config['baseurl'] . '/admin/index.php', $this->page);
			if (isset($_SESSION['userID'])) {
				$this->page = str_replace('{url_edit_profile}', $config['baseurl'] . '/edit_profile_' . $_SESSION['userID'] . '.html', $this->page);
			}
		}
	}
	function replace_meta_template_tags()
	{
		global $config, $lang;
		if (isset($_GET['listingID'])) {
			$listing_keywords = $this->replace_listing_field_tags($_GET['listingID'], $config['seo_listing_keywords']);
			$listing_keywords = strip_tags(str_replace(array("\r\n", "\r", "\n", '||'), array('', '', '', ','), $listing_keywords));
			$this->page = str_replace('{load_meta_keywords}', '<meta name="keywords" content="' . $listing_keywords . '" />', $this->page);

			$listing_description = $this->replace_listing_field_tags($_GET['listingID'], $config['seo_listing_description']);
			$listing_description = strip_tags(str_replace(array("\r\n", "\r", "\n", '||'), array('', '', '', ','), $listing_description));
			$this->page = str_replace('{load_meta_description}', '<meta name="description" content="' . $listing_description . '" />', $this->page);
			// Handle Site Title
			$listing_title = $this->replace_listing_field_tags($_GET['listingID'], $config['seo_listing_title']);
			$listing_title = strip_tags(str_replace(array("\r\n", "\r", "\n", '||'), array('', '', '', ','), $listing_title));
			$this->page = str_replace('{site_title}', $listing_title, $this->page);
		} else if ($_GET['action'] == 'view_users') {
			$this->page = str_replace('{load_meta_keywords}', '<meta name="keywords" content="' . $config['seo_default_keywords'] . '" />', $this->page);
			$this->page = str_replace('{load_meta_description}', '<meta name="description" content="' . $config['seo_default_description'] . '" />', $this->page);
			$this->page = str_replace('{site_title}', $config['seo_default_title'] . ' - ' . $lang['menu_view_agents'], $this->page);
		} else if ($_GET['action'] == 'view_listing_image') {
			if (isset($_GET['image_id'])) {
				require_once($config['basepath'] . '/include/images.inc.php');
				$title = image_handler::get_image_caption();
				$this->page = str_replace('{load_meta_keywords}', '<meta name="keywords" content="' . $config['seo_default_keywords'] . '" />', $this->page);
				$this->page = str_replace('{load_meta_description}', '<meta name="description" content="' . $config['seo_default_description'] . '" />', $this->page);
				$this->page = str_replace('{site_title}', $config['seo_default_title'] . ' - ' . $title, $this->page);
			} else {
				$this->page = str_replace('{load_meta_keywords}', '<meta name="keywords" content="' . $config['seo_default_keywords'] . '" />', $this->page);
				$this->page = str_replace('{load_meta_description}', '<meta name="description" content="' . $config['seo_default_description'] . '" />', $this->page);
				$this->page = str_replace('{site_title}', $config['seo_default_title'], $this->page);
			}
		} else if (isset($_GET['PageID'])) {
			require_once($config['basepath'] . '/include/page_display.inc.php');
			$title = page_display::get_page_title($_GET['PageID']);
			$description = page_display::get_page_description($_GET['PageID']);
			$keywords = page_display::get_page_keywords($_GET['PageID']);
			if ($description == '') {
				$description = $config['seo_default_description'];
			}
			if ($keywords == '') {
				$keywords = $config['seo_default_keywords'];
			}
			$this->page = str_replace('{load_meta_keywords}', '<meta name="keywords" content="' . $keywords . '" />', $this->page);
			$this->page = str_replace('{load_meta_description}', '<meta name="description" content="' . $description . '" />', $this->page);
			$this->page = str_replace('{site_title}', $config['seo_default_title'] . ' - ' . $title, $this->page);
		} else {
			$this->page = str_replace('{load_meta_keywords}', '<meta name="keywords" content="' . $config['seo_default_keywords'] . '" />', $this->page);
			$this->page = str_replace('{load_meta_description}', '<meta name="description" content="' . $config['seo_default_description'] . '" />', $this->page);
			$this->page = str_replace('{site_title}', $config['seo_default_title'], $this->page);
		}
	}
	function replace_css_template_tags($admin = false)
	{
		if ($admin == true) {
			$this->page = preg_replace_callback('/{load_css_(.*?)}/', create_function('$matches',
					'global $config,$listing_id,$lang;
				$css = new page_admin;$css->load_page($config["admin_template_path"]."/$matches[1].css");
				$css->replace_tags(array("company_logo","baseurl","template_url"));
				$css_text = "<style type=\"text/css\"><!-- ".$css->return_page()." --></style>";
				return $css_text;
				'), $this->page);
		} else {
			$this->page = preg_replace_callback('/{load_css_(.*?)}/', create_function('$matches',
					'global $config,$listing_id,$lang;
				$css = new page_user;$css->load_page($config["template_path"]."/$matches[1].css");
				$css->replace_tags(array("company_logo","baseurl","template_url"));
				$css_text = "<style type=\"text/css\"><!-- ".$css->return_page()." --></style>";
				return $css_text;
				'), $this->page);
		}
	}
	function replace_lang_template_tags()
	{
		// $this->page = preg_replace('/{lang_(.*?)}/is', $lang["$1"], $this->page);
		$this->page = preg_replace_callback('/{lang_(.*?)}/is', create_function('$matches',
				'global $lang; return $lang[$matches[1]];'), $this->page);
	}
	function parse_addon_tags($section_as_variable, $fields)
	{
		foreach($fields as $field) {
			global $config;
			if ($field == '') {
				continue;
			}
			// Make sure that the tag is in the section
			if (strpos($section_as_variable, $field) !== false) {
				$addon_name = array();
				if (preg_match("/^addon_(.*?)_.*/", $field, $addon_name)) {
					include_once($config['basepath'] . '/addons/' . $addon_name[1] . '/addon.inc.php');
					$function_name = $addon_name[1] . '_run_template_user_fields';
					$value = $function_name($field);
					$section_as_variable = str_replace('{' . $field . '}', $value, $section_as_variable);
				}
			}
		}

		return $section_as_variable;
	}
	function cleanup_template_sections($next_prev = '')
	{
		// Insert Next Prev where needed
		$section = '{next_prev}';
		$this->page = str_replace($section, $next_prev, $this->page);
		// Renmove any unused blocks
		$section = '/{(.*?)_block}.*?{\/\1_block}/is';
		$this->page = preg_replace($section, '', $this->page);
		// Remove any unused tags
		// $section = '/{.*?}/i';
		// $this->page = preg_replace($section, '', $this->page);
	}

	function replace_listing_field_tags($listing_id, $tempate_section = '', $utf8HTML = false)
	{
		global $lang;
		if (is_numeric($listing_id)) {
			global $config, $conn, $or_replace_listing_id, $or_replace_listing_owner;
			$or_replace_listing_id = $listing_id;
			require_once($config['basepath'] . '/include/listing.inc.php');
			require_once($config['basepath'] . '/include/vtour.inc.php');
			require_once($config['basepath'] . '/include/misc.inc.php');
			$misc = new misc();
			if ($tempate_section != '') {
				$tsection = true;
			} else {
				$tempate_section = $this->page;
				$tsection = false;
			}
			if ($utf8HTML) {
				// Handle Caption Only
				$tempate_section = preg_replace_callback('/{listing_field_([^{}]*?)_caption}/', create_function('$matches',
						'global $config,$or_replace_listing_id,$lang;require_once($config[\'basepath\'].\'/include/listing.inc.php\');
					return htmlentities(utf8_encode(listing_pages::renderSingleListingItem($or_replace_listing_id, $matches[1],\'caption\')), ENT_QUOTES, \'UTF-8\');'), $tempate_section);
				// Hanle VlaueOnly
				$tempate_section = preg_replace_callback('/{listing_field_([^{}]*?)_value}/', create_function('$matches',
						'global $config,$or_replace_listing_id,$lang;require_once($config[\'basepath\'].\'/include/listing.inc.php\');
					return htmlentities(utf8_encode(listing_pages::renderSingleListingItem($or_replace_listing_id, $matches[1],\'value\')), ENT_QUOTES, \'UTF-8\');'), $tempate_section);
				// Handle Raw Value
				$tempate_section = preg_replace_callback('/{listing_field_([^{}]*?)_rawvalue}/', create_function('$matches',
						'global $config,$or_replace_listing_id,$lang;require_once($config[\'basepath\'].\'/include/listing.inc.php\');
					return htmlentities(utf8_encode(listing_pages::renderSingleListingItem($or_replace_listing_id, $matches[1],\'rawvalue\')), ENT_QUOTES, \'UTF-8\');'), $tempate_section);
				// Handle Both Caption and Value
				$tempate_section = preg_replace_callback('/{listing_field_([^{}]*?)}/', create_function('$matches',
						'global $config,$or_replace_listing_id,$lang;require_once($config[\'basepath\'].\'/include/listing.inc.php\');
					return htmlentities(utf8_encode(listing_pages::renderSingleListingItem($or_replace_listing_id, $matches[1])), ENT_QUOTES, \'UTF-8\');'), $tempate_section);

				$value = htmlentities(utf8_encode(listing_pages::get_title($listing_id)), ENT_QUOTES, 'UTF-8');
				$tempate_section = str_replace('{listing_title}', $value, $tempate_section);
				$value = htmlentities(utf8_encode(listing_pages::getListingAgent($listing_id)), ENT_QUOTES, 'UTF-8');
				$tempate_section = str_replace('{listing_agent_name}', $value, $tempate_section);
				$value = htmlentities(utf8_encode(listing_pages::getListingAgentFirstName($listing_id)), ENT_QUOTES, 'UTF-8');
				$tempate_section = str_replace('{listing_agent_first_name}', $value, $tempate_section);
				$value = htmlentities(utf8_encode(listing_pages::getListingAgentLastName($listing_id)), ENT_QUOTES, 'UTF-8');
				$tempate_section = str_replace('{listing_agent_last_name}', $value, $tempate_section);
				$value = htmlentities(utf8_encode(listing_pages::getListingAgentLink($listing_id)), ENT_QUOTES, 'UTF-8');
				$tempate_section = str_replace('{listing_agent_link}', $value, $tempate_section);
				$value = htmlentities(utf8_encode(listing_pages::get_pclass($listing_id)), ENT_QUOTES, 'UTF-8');
				$tempate_section = str_replace('{listing_pclass}', $value, $tempate_section);
				$value = htmlentities(utf8_encode(listing_pages::getAgentListingsLink($listing_id)), ENT_QUOTES, 'UTF-8');
				$tempate_section = str_replace('{listing_agent_listings}', $value, $tempate_section);
				$value = htmlentities(utf8_encode(listing_pages::getListingAgentID($listing_id)), ENT_QUOTES, 'UTF-8');
				$tempate_section = str_replace('{listing_agent_id}', $value, $tempate_section);
				// Get Creation date and Last Modified Date
				$value = htmlentities(utf8_encode(listing_pages::get_creation_date($listing_id)), ENT_QUOTES, 'UTF-8');
				$tempate_section = str_replace('{listing_creation_date}', $value, $tempate_section);
				$value = htmlentities(utf8_encode(listing_pages::get_modified_date($listing_id)), ENT_QUOTES, 'UTF-8');
				$tempate_section = str_replace('{listing_modified_date}', $value, $tempate_section);
				// Get listing owner
				$owner_sql = 'SELECT userdb_id FROM ' . $config['table_prefix'] . 'listingsdb WHERE (listingsdb_id = ' . $or_replace_listing_id . ')';
				$recordSet = $conn->execute($owner_sql);
				$or_replace_listing_owner = $recordSet->fields['userdb_id'];
				//New listing_agent_field_****_block tag handler for 2.4.1
				//int preg_match_all ( string $pattern, string $subject, array &$matches [, int $flags [, int $offset]] )
				$laf_blocks=array();
				//{listing_agent_field_mobile_block}
				preg_match_all('/{listing_agent_field_([^{}]*?)_block}/',$tempate_section,$laf_blocks);
				//echo '<pre>'.print_r($laf_blocks,TRUE).'</pre>';
				require_once($config['basepath'].'/include/user.inc.php');
				global $or_replace_listing_owner;
				if(count($laf_blocks) > 1){
					foreach($laf_blocks[1] as $block){
						//if(strpos($block[0],'{')===0 || empty($block)){continue;}
					//	echo '<pre>'.print_r($block,TRUE).'</pre>';
						$value = user::renderSingleListingItem($or_replace_listing_owner, $block,'rawvalue');
					//	print "value: $value \r\n";
						if($value == ''){
							$tempate_section = preg_replace('/{listing_agent_field_'.$block.'_block}(.*?){\/listing_agent_field_'.$block.'_block}/is', '', $tempate_section);
						}else{
							$tempate_section = str_replace('{listing_agent_field_'.$block.'_block}', '', $tempate_section);
							$tempate_section = str_replace('{/listing_agent_field_'.$block.'_block}', '', $tempate_section);
						}
					}
				}// REplace listing_agent tags
				// Handle Caption Only
				$tempate_section = preg_replace_callback('/{listing_agent_field_([^{}]*?)_caption}/', create_function('$matches',
						'global $config,$or_replace_listing_owner,$lang;require_once($config[\'basepath\'].\'/include/user.inc.php\');
					return htmlentities(utf8_encode(user::renderSingleListingItem($or_replace_listing_owner, $matches[1],\'caption\')), ENT_QUOTES, \'UTF-8\');'), $tempate_section);
				// Hanle VlaueOnly
				$tempate_section = preg_replace_callback('/{listing_agent_field_([^{}]*?)_value}/', create_function('$matches',
						'global $config,$or_replace_listing_owner,$lang;require_once($config[\'basepath\'].\'/include/user.inc.php\');
					return htmlentities(utf8_encode(user::renderSingleListingItem($or_replace_listing_owner, $matches[1],\'value\')), ENT_QUOTES, \'UTF-8\');'), $tempate_section);
				// Handle Raw Value
				$tempate_section = preg_replace_callback('/{listing_agent_field_([^{}]*?)_rawvalue}/', create_function('$matches',
						'global $config,$or_replace_listing_owner,$lang;require_once($config[\'basepath\'].\'/include/user.inc.php\');
					return htmlentities(utf8_encode(user::renderSingleListingItem($or_replace_listing_owner, $matches[1],\'rawvalue\')), ENT_QUOTES, \'UTF-8\');'), $tempate_section);
				// Handle Both Caption and Value
				$tempate_section = preg_replace_callback('/{listing_agent_field_([^{}]*?)}/', create_function('$matches',
						'global $config,$or_replace_listing_owner,$lang;require_once($config[\'basepath\'].\'/include/user.inc.php\');
					return htmlentities(utf8_encode(user::renderSingleListingItem($or_replace_listing_owner, $matches[1])), ENT_QUOTES, \'UTF-8\');'), $tempate_section);
			} else {
				// Handle Caption Only
				$tempate_section = preg_replace_callback('/{listing_field_([^{}]*?)_caption}/', create_function('$matches',
						'global $config,$or_replace_listing_id,$lang;require_once($config[\'basepath\'].\'/include/listing.inc.php\');
					return listing_pages::renderSingleListingItem($or_replace_listing_id, $matches[1],\'caption\');'), $tempate_section);
				// Hanle VlaueOnly
				$tempate_section = preg_replace_callback('/{listing_field_([^{}]*?)_value}/', create_function('$matches',
						'global $config,$or_replace_listing_id,$lang;require_once($config[\'basepath\'].\'/include/listing.inc.php\');
					return listing_pages::renderSingleListingItem($or_replace_listing_id, $matches[1],\'value\');'), $tempate_section);
				// Handle Raw Value
				$tempate_section = preg_replace_callback('/{listing_field_([^{}]*?)_rawvalue}/', create_function('$matches',
						'global $config,$or_replace_listing_id,$lang;require_once($config[\'basepath\'].\'/include/listing.inc.php\');
					return listing_pages::renderSingleListingItem($or_replace_listing_id, $matches[1],\'rawvalue\');'), $tempate_section);
				// Handle Both Caption and Value
				$tempate_section = preg_replace_callback('/{listing_field_([^{}]*?)}/', create_function('$matches',
						'global $config,$or_replace_listing_id,$lang;require_once($config[\'basepath\'].\'/include/listing.inc.php\');
					return listing_pages::renderSingleListingItem($or_replace_listing_id, $matches[1]);'), $tempate_section);
				$value = listing_pages::get_title($listing_id);
				$tempate_section = str_replace('{listing_title}', $value, $tempate_section);
				$value = listing_pages::getListingAgent($listing_id);
				$tempate_section = str_replace('{listing_agent_name}', $value, $tempate_section);
				$value = listing_pages::getListingAgentFirstName($listing_id);
				$tempate_section = str_replace('{listing_agent_first_name}', $value, $tempate_section);
				$value = listing_pages::getListingAgentLastName($listing_id);
				$tempate_section = str_replace('{listing_agent_last_name}', $value, $tempate_section);
				$value = listing_pages::getListingAgentLink($listing_id);
				$tempate_section = str_replace('{listing_agent_link}', $value, $tempate_section);
				$value = listing_pages::get_pclass($listing_id);
				$tempate_section = str_replace('{listing_pclass}', $value, $tempate_section);
				$value = listing_pages::getAgentListingsLink($listing_id);
				$tempate_section = str_replace('{listing_agent_listings}', $value, $tempate_section);
				$value = listing_pages::getListingAgentID($listing_id);
				$tempate_section = str_replace('{listing_agent_id}', $value, $tempate_section);
				// Get Creation date and Last Modified Date
				$value = listing_pages::get_creation_date($listing_id);
				$tempate_section = str_replace('{listing_creation_date}', $value, $tempate_section);
				$value = listing_pages::get_modified_date($listing_id);
				$tempate_section = str_replace('{listing_modified_date}', $value, $tempate_section);
				// Get listing owner
				$owner_sql = 'SELECT userdb_id FROM ' . $config['table_prefix'] . 'listingsdb WHERE (listingsdb_id = ' . $or_replace_listing_id . ')';
				$recordSet = $conn->execute($owner_sql);
				$or_replace_listing_owner = $recordSet->fields['userdb_id'];
				//New listing_agent_field_****_block tag handler for 2.4.1
				//int preg_match_all ( string $pattern, string $subject, array &$matches [, int $flags [, int $offset]] )
				$laf_blocks=array();
				//{listing_agent_field_mobile_block}
				preg_match_all('/{listing_agent_field_([^{}]*?)_block}/',$tempate_section,$laf_blocks);
				//echo '<pre>'.print_r($laf_blocks,TRUE).'</pre>';
				require_once($config['basepath'].'/include/user.inc.php');
				global $or_replace_listing_owner;
				if(count($laf_blocks) > 1){
					foreach($laf_blocks[1] as $block){
						//if(strpos($block[0],'{')===0 || empty($block)){continue;}
					//	echo '<pre>'.print_r($block,TRUE).'</pre>';
						$value = user::renderSingleListingItem($or_replace_listing_owner, $block,'rawvalue');
					//	print "value: $value \r\n";
						if($value == ''){
							$tempate_section = preg_replace('/{listing_agent_field_'.$block.'_block}(.*?){\/listing_agent_field_'.$block.'_block}/is', '', $tempate_section);
						}else{
							$tempate_section = str_replace('{listing_agent_field_'.$block.'_block}', '', $tempate_section);
							$tempate_section = str_replace('{/listing_agent_field_'.$block.'_block}', '', $tempate_section);
						}
					}
				}
				// REplace listing_agent tags
				// Handle Caption Only
				$tempate_section = preg_replace_callback('/{listing_agent_field_([^{}]*?)_caption}/', create_function('$matches',
						'global $config,$or_replace_listing_owner,$lang;require_once($config[\'basepath\'].\'/include/user.inc.php\');
					return user::renderSingleListingItem($or_replace_listing_owner, $matches[1],\'caption\');'), $tempate_section);
				// Hanle VlaueOnly
				$tempate_section = preg_replace_callback('/{listing_agent_field_([^{}]*?)_value}/', create_function('$matches',
						'global $config,$or_replace_listing_owner,$lang;require_once($config[\'basepath\'].\'/include/user.inc.php\');
					return user::renderSingleListingItem($or_replace_listing_owner, $matches[1],\'value\');'), $tempate_section);
				// Handle Raw Value
				$tempate_section = preg_replace_callback('/{listing_agent_field_([^{}]*?)_rawvalue}/', create_function('$matches',
						'global $config,$or_replace_listing_owner,$lang;require_once($config[\'basepath\'].\'/include/user.inc.php\');
					return user::renderSingleListingItem($or_replace_listing_owner, $matches[1],\'rawvalue\');'), $tempate_section);
				// Handle Both Caption and Value
				$tempate_section = preg_replace_callback('/{listing_agent_field_([^{}]*?)}/', create_function('$matches',
						'global $config,$or_replace_listing_owner,$lang;require_once($config[\'basepath\'].\'/include/user.inc.php\');
					return user::renderSingleListingItem($or_replace_listing_owner, $matches[1]);'), $tempate_section);
			}
			// Listing Link
			$tempate_section = str_replace('{link_to_listing}', 'index.php?action=listingview&amp;listingID=' . $listing_id, $tempate_section);
			$tempate_section = str_replace('{fulllink_to_listing}', $config['baseurl'] . '/index.php?action=listingview&amp;listingID=' . $listing_id, $tempate_section);
			// Listing Images
			$sql2 = "SELECT listingsdb_title FROM " . $config['table_prefix'] . "listingsdb WHERE listingsdb_id = $listing_id";
			$recordSet2 = $conn->Execute($sql2);
			if (!$recordSet2) {
				$misc->log_error($sql2);
			}
			$Title = $misc->make_db_unsafe ($recordSet2->fields['listingsdb_title']);
			if ($config['url_style'] == '1') {
				$url = '<a href="index.php?action=listingview&amp;listingID=' . $listing_id . '">';
				$fullurl = '<a href="' . $config["baseurl"] . '/index.php?action=listingview&amp;listingID=' . $listing_id . '">';
			} else {
				$url_title = str_replace("-", "", $Title);
				$url_title = str_replace("/", "", $url_title);
				$url = '<a href="listing-' . urlencode($url_title) . '-' . $listing_id . '.html">';
				$fullurl = '<a href="' . $config["baseurl"] . '/listing-' . urlencode($url_title) . '-' . $listing_id . '.html">';
			}
			// grab the listing's image
			$sql2 = "SELECT listingsimages_thumb_file_name, listingsimages_file_name FROM " . $config['table_prefix'] . "listingsimages WHERE listingsdb_id = $listing_id ORDER BY listingsimages_rank";
			$recordSet2 = $conn->Execute($sql2);
			if (!$recordSet2) {
				$misc->log_error($sql2);
			}
			$num_images = $recordSet2->RecordCount();
			if ($num_images == 0) {
				if ($config['show_no_photo'] == 1) {
					$listing_image = $url . '<img src="' . $config["baseurl"] . '/images/nophoto.gif" alt="' . $lang['no_photo'] . '" /></a>';
					$listing_image_full = $fullurl . '<img src="' . $config["baseurl"] . '/images/nophoto.gif" alt="' . $lang['no_photo'] . '" /></a>';
					$tempate_section = str_replace('{raw_image_thumb_1}', $config['baseurl'] . '/images/nophoto.gif', $tempate_section);
				} else {
					$listing_image = '';
					$tempate_section = str_replace('{raw_image_thumb_1}', '', $tempate_section);
				}
				$tempate_section = str_replace('{image_thumb_1}', $listing_image, $tempate_section);
				$tempate_section = str_replace('{image_thumb_fullurl_1}', $listing_image, $tempate_section);
			}
			$x = 1;
			while (!$recordSet2->EOF) {
				$thumb_file_name = $misc->make_db_unsafe ($recordSet2->fields['listingsimages_thumb_file_name']);
				$full_file_name = $misc->make_db_unsafe ($recordSet2->fields['listingsimages_file_name']);
				if ($thumb_file_name != "" && file_exists("$config[listings_upload_path]/$thumb_file_name")) {
					// gotta grab the image size
					$imagedata = GetImageSize("$config[listings_upload_path]/$full_file_name");
					$imagewidth = $imagedata[0];
					$imageheight = $imagedata[1];
					$shrinkage = $config['thumbnail_width'] / $imagewidth;
					$displaywidth = $imagewidth * $shrinkage;
					$displayheight = $imageheight * $shrinkage;
					$listing_image = $url . '<img src="' . $config['listings_view_images_path'] . '/' . $thumb_file_name . '" height="' . $displayheight . '" width="' . $displaywidth . '" alt="' . $thumb_file_name . '" /></a>';
					$listing_image_full = $url . '<img src="' . $config['listings_view_images_path'] . '/' . $full_file_name . '" height="' . $imageheight . '" width="' . $imagewidth . '" alt="' . $full_file_name . '" /></a>';
					$listing_image_fullurl = $fullurl . '<img src="' . $config['listings_view_images_path'] . '/' . $thumb_file_name . '" height="' . $displayheight . '" width="' . $displaywidth . '" alt="' . $thumb_file_name . '" /></a>';
					$listing_image_full_fullurl = $fullurl . '<img src="' . $config['listings_view_images_path'] . '/' . $full_file_name . '" height="' . $imageheight . '" width="' . $imagewidth . '" alt="' . $full_file_name . '" /></a>';
					$tempate_section = str_replace('{image_thumb_' . $x . '}', $listing_image, $tempate_section);
					$tempate_section = str_replace('{raw_image_thumb_' . $x . '}', $config['listings_view_images_path'] . '/' . $thumb_file_name, $tempate_section);
					$tempate_section = str_replace('{image_thumb_fullurl_' . $x . '}', $listing_image_fullurl, $tempate_section);
					//Full Image tags
					$tempate_section = str_replace('{image_full_' . $x . '}', $listing_image_full, $tempate_section);
					$tempate_section = str_replace('{raw_image_full_' . $x . '}', $config['listings_view_images_path'] . '/' . $full_file_name, $tempate_section);
					$tempate_section = str_replace('{image_full_fullurl_' . $x . '}', $listing_image_full_fullurl, $tempate_section);
				} else {
					if ($config['show_no_photo'] == 1) {
						$listing_image = $url . '<img src="' . $config["baseurl"] . '/images/nophoto.gif" alt="' . $lang['no_photo'] . '" /></a>';
						$listing_image_fullurl = $fullurl . '<img src="' . $config["baseurl"] . '/images/nophoto.gif" alt="' . $lang['no_photo'] . '" /></a>';
						$tempate_section = str_replace('{raw_image_thumb_' . $x . '}', $config['baseurl'] . '/images/nophoto.gif', $tempate_section);
					} else {
						$listing_image = '';
						$tempate_section = str_replace('{raw_image_thumb_' . $x . '}', '', $tempate_section);
					}
					$tempate_section = str_replace('{image_thumb_' . $x . '}', $listing_image, $tempate_section);
					$tempate_section = str_replace('{image_thumb_fullurl_' . $x . '}', $listing_image_fullurl, $tempate_section);
					$tempate_section = str_replace('{image_full_' . $x . '}', '', $tempate_section);
					$tempate_section = str_replace('{raw_image_full_' . $x . '}', '', $tempate_section);
					$tempate_section = str_replace('{image_full_fullurl_' . $x . '}', '', $tempate_section);
				}
				// We have the image so insert it into the section.
				$x++;
				$recordSet2->MoveNext();
			} // end while
			// End Listing Images
			$value = array();
			$value = listing_pages::getListingAgentThumbnail($listing_id);
			$x = 0;
			foreach($value as $y) {
				$tempate_section = str_replace('{listing_agent_thumbnail_' . $x . '}', $y, $tempate_section);
				$x++;
			}
			$tempate_section = preg_replace('/{listing_agent_thumbnail_([^{}]*?)}/', '', $tempate_section);
			// End of Listing Tag Replacement
			if ($tsection === true) {
				return $tempate_section;
			} else {
				$this->page = $tempate_section;
			}
		}
	}
}
class page_user extends page {
	function replace_user_action()
	{
		global $lang, $config;
		require_once($config['basepath'] . '/include/login.inc.php');
		$login = new login();
		switch ($_GET['action']) {
			case 'index':
				$_GET['PageID'] = 1;
				require_once($config['basepath'] . '/include/page_display.inc.php');
				$search = new page_display();
				$data = $search->display();
				break;
			case 'member_login':
				$data = $login->display_login('Member');
				break;
			case 'search_step_2':
				require_once($config['basepath'] . '/include/search.inc.php');
				$search = new search_page();
				$data = $search->create_searchpage();
				break;
			case 'searchpage':
				require_once($config['basepath'] . '/include/search.inc.php');
				$search = new search_page();
				$data = $search->create_search_page_logic();
				break;
			case 'searchresults':
				require_once($config['basepath'] . '/include/search.inc.php');
				$search = new search_page();
				$data = $search->search_results();
				break;
			case 'listingview':
				require_once($config['basepath'] . '/include/listing.inc.php');
				$listing = new listing_pages();
				$data = $listing->listing_view();
				break;
			case 'addtofavorites':
				require_once($config['basepath'] . '/include/members_favorites.inc.php');
				$listing = new membersfavorites();
				$data = $listing->addtofavorites();
				break;
			case 'view_favorites':
				require_once($config['basepath'] . '/include/members_favorites.inc.php');
				$listing = new membersfavorites();
				$data = $listing->view_favorites();
				break;
			case 'view_saved_searches':
				require_once($config['basepath'] . '/include/members_search.inc.php');
				$listing = new memberssearch();
				$data = $listing->view_saved_searches();
				break;
			case 'save_search':
				require_once($config['basepath'] . '/include/members_search.inc.php');
				$listing = new memberssearch();
				$data = $listing->save_search();
				break;
			case 'delete_search':
				require_once($config['basepath'] . '/include/members_search.inc.php');
				$listing = new memberssearch();
				$data = $listing->delete_search();
				break;
			case 'delete_favorites':
				require_once($config['basepath'] . '/include/members_favorites.inc.php');
				$listing = new membersfavorites();
				$data = $listing->delete_favorites();
				break;
			case 'page_display':
				require_once($config['basepath'] . '/include/page_display.inc.php');
				$search = new page_display();
				$data = $search->display();
				break;
			case 'calculator':
				require_once($config['basepath'] . '/include/calculators.inc.php');
				$calc = new calculators();
				$data = $calc->start_calc();
				break;
			case 'view_listing_image':
				require_once($config['basepath'] . '/include/images.inc.php');
				$image = new image_handler();
				$data = $image->view_image('listing');
				break;
			case 'view_user_image':
				require_once($config['basepath'] . '/include/images.inc.php');
				$image = new image_handler();
				$data = $image->view_image('userimage');
				break;
			case 'rss_featured_listings':
				require_once($config['basepath'] . '/include/rss.inc.php');
				$rss = new rss();
				$data = $rss->rss_view('featured');
				break;
			case 'rss_lastmodified_listings':
				require_once($config['basepath'] . '/include/rss.inc.php');
				$rss = new rss();
				$data = $rss->rss_view('lastmodified');
				break;
			case 'view_user':
				require_once($config['basepath'] . '/include/user.inc.php');
				$user = new user();
				$data = $user->view_user();
				break;
			case 'view_users':
				require_once($config['basepath'] . '/include/user.inc.php');
				$user = new user();
				$data = $user->view_users();
				break;
			case 'edit_profile':
				require_once($config['basepath'] . '/include/user_manager.inc.php');
				if (!isset($_GET['user_id'])) {
					$_GET['user_id'] = 0;
				}
				$user_managment = new user_managment();
				$data = $user_managment->edit_member_profile($_GET['user_id']);
				break;
			case 'signup':
				if (isset($_GET['type'])) {
					require_once($config['basepath'] . '/include/user_manager.inc.php');
					$listing = new user_managment();
					$data = $listing->user_signup($_GET['type']);
				}
				break;
			case 'show_vtour':
				if (isset($_GET['listingID'])) {
					require_once($config['basepath'] . '/include/vtour.inc.php');
					$vtour = new vtours();
					$data = $vtour->show_vtour($_GET['listingID']);
				} else {
					$data = 'No Listing ID';
				}
				break;
			case 'contact_friend':
				require_once($config['basepath'] . '/include/contact.inc.php');
				$contact = new contact();
				if (isset($_GET['listing_id'])) {
					$data = $contact->ContactFriendForm($_GET['listing_id']);
				}
				break;
			case 'contact_agent':
				require_once($config['basepath'] . '/include/contact.inc.php');
				$contact = new contact();
				if (isset($_GET['listing_id']) && isset($_GET['agent_id'])) {
					$data = $contact->ContactAgentForm($_GET['listing_id'], $_GET['agent_id']);
				} elseif (isset($_GET['listing_id'])) {
					$data = $contact->ContactAgentForm($_GET['listing_id'], 0);
				} elseif (isset($_GET['agent_id'])) {
					$data = $contact->ContactAgentForm(0, $_GET['agent_id']);
				} else {
					$data = '';
				}
				break;
			case 'create_vcard':
				require_once($config['basepath'] . '/include/user.inc.php');
				$user = new user();
				if (isset($_GET['user'])) {
					$data = $user->create_vcard($_GET['user']);
				}
				break;
			default:
				$addon_name = array();
				if (preg_match("/^addon_(.*?)_.*/", $_GET['action'], $addon_name)) {
					include_once($config['basepath'] . '/addons/' . $addon_name[1] . '/addon.inc.php');
					$function_name = $addon_name[1] . '_run_action_user_template';
					$data = $function_name();
				} else {
					$data = '';
				}
				break;
		} // End switch ($_GET['action'])
		return $data;
	}
	function replace_tags($tags = array())
	{
		global $config, $lang;
		require_once($config['basepath'] . '/include/login.inc.php');
		$login = new login();
		require_once($config['basepath'] . '/include/misc.inc.php');
		$misc = new misc();
		// Remove tags not found in teh template
		$new_tags = $tags;
		$tags = array();
		foreach($new_tags as $tag) {
			if (strpos($this->page, '{' . $tag . '}') !== false) {
				$tags[] = $tag;
			}
		}
		unset($new_tags);
		if (sizeof($tags) > 0) {
			foreach ($tags as $tag) {
				$data = '';
				switch ($tag) {
					case 'content':
						$data = $this->replace_user_action();
						break;
					case 'templated_search_form';
						require_once($config['basepath'] . '/include/search.inc.php');
						$search = new search_page();
						$data = $search->create_searchpage('no', true);
						break;
					case 'baseurl':
						$data = $config['baseurl'];
						break;
					case 'template_url':
						$data = $config['template_url'];
						break;
					case 'load_js':
						$data = $this->load_js();
						break;
					case 'load_js_last':
						global $jscript_last;
						$data = $jscript_last;
						break;
					case 'tabbed_js':
						global $jscript;
						$jscript = '<script type="text/javascript" src="' . $config['baseurl'] . '/tabpane.js"></script>' . "\r\n";
						$data = '';
						break;
					case 'license_tag':
						$data = "<!--Open-Realty is distributed by Transparent	Technologies and is Licensed under the Open-Realty License. See http://www.open-realty.org/license_info.html for more information.-->";
						break;
					case 'main_listing_data':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->getMainListingData($_GET['listingID']);
						break;
					case 'featured_listings_vertical':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->renderFeaturedListingsVertical();
						break;
					case 'featured_listings_horizontal':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->renderFeaturedListingsHorizontal();
						break;
					case 'random_listings_vertical':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->renderFeaturedListingsVertical(0, true);
						break;
					case 'random_listings_horizontal':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->renderFeaturedListingsHorizontal(0, true);
						break;
					case 'headline':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->renderTemplateAreaNoCaption('headline', $_GET['listingID']);
						break;
					case 'listing_images':
						require_once($config['basepath'] . '/include/images.inc.php');
						$images = new image_handler();
						$data = $images->renderListingsImages($_GET['listingID'], 'yes');
						break;
					case 'listing_images_nocaption':
						require_once($config['basepath'] . '/include/images.inc.php');
						$images = new image_handler();
						$data = $images->renderListingsImages($_GET['listingID'], 'no');
						break;
					case 'slideshow_images':
						require_once($config['basepath'] . '/include/images.inc.php');
						$images = new image_handler();
						$data = $images->renderListingsMainImageSlideShow($_GET['listingID']);
						break;
					case 'link_calc':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->create_calc_link();
						break;
					case 'link_calc_url':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->create_calc_link($url_only = 'yes');
						break;
					case 'link_add_favorites':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->create_add_favorite_link();
						break;
					case 'link_add_favorites_url':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->create_add_favorite_link($url_only = 'yes');
						break;
					case 'link_printer_friendly':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->create_printer_friendly_link();
						break;
					case 'link_email_friend':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->create_email_friend_link();
						break;
					case 'link_map':
						require_once($config['basepath'] . '/include/maps.inc.php');
						$maps = new maps();
						$data = $maps->create_map_link();
						break;
					case 'link_yahoo_school':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->create_yahoo_school_link();
						break;
					case 'link_yahoo_neighborhood':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->create_yahoo_neighborhood_link();
						break;
					case 'link_printer_friendly_url':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->create_printer_friendly_link($url_only = 'yes');
						break;
					case 'link_email_friend_url':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->create_email_friend_link($url_only = 'yes');
						break;
					case 'link_map_url':
						require_once($config['basepath'] . '/include/maps.inc.php');
						$maps = new maps();
						$data = $maps->create_map_link($url_only = 'yes');
						break;
					case 'link_yahoo_school_url':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->create_yahoo_school_link($url_only = 'yes');
						break;
					case 'link_yahoo_neighborhood_url':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->create_yahoo_neighborhood_link($url_only = 'yes');
						break;
					case 'contact_agent_link_url':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->contact_agent_link($url_only = 'yes');
						break;
					case 'agent_info':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->renderUserInfoOnListingsPage($_GET['listingID']);
						break;
					case 'listing_email':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->getListingEmail($_GET['listingID']);
						break;
					case 'hitcount':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->hitcount($_GET['listingID']);
						break;
					case 'main_image':
						require_once($config['basepath'] . '/include/images.inc.php');
						$images = new image_handler();
						$data = $images->renderListingsMainImage($_GET['listingID'], 'yes', 'no');
						break;
					case 'main_image_nodesc':
						require_once($config['basepath'] . '/include/images.inc.php');
						$images = new image_handler();
						$data = $images->renderListingsMainImage($_GET['listingID'], 'no', 'no');
						break;
					case 'main_image_java':
						require_once($config['basepath'] . '/include/images.inc.php');
						$images = new image_handler();
						$data = $images->renderListingsMainImage($_GET['listingID'], 'yes', 'yes');
						break;
					case 'main_image_java_nodesc':
						require_once($config['basepath'] . '/include/images.inc.php');
						$images = new image_handler();
						$data = $images->renderListingsMainImage($_GET['listingID'], 'no', 'yes');
						break;
					case 'listing_images_java':
						require_once($config['basepath'] . '/include/images.inc.php');
						$images = new image_handler();
						$data = $images->renderListingsImagesJava($_GET['listingID'], 'no');
						break;
					case 'listing_images_java_caption':
						require_once($config['basepath'] . '/include/images.inc.php');
						$images = new image_handler();
						$data = $images->renderListingsImagesJava($_GET['listingID'], 'yes');
						break;
					case 'listing_images_java_rows':
						require_once($config['basepath'] . '/include/images.inc.php');
						$images = new image_handler();
						$data = $images->renderListingsImagesJavaRows($_GET['listingID']);
						break;
					case 'vtour_button':
						require_once($config['basepath'] . '/include/vtour.inc.php');
						$vtour = new vtours();
						$data = $vtour->rendervtourlink($_GET['listingID']);
						break;
					case 'listingid':
						$data = $_GET['listingID'];
						break;
					case 'contact_agent_link':
						require_once($config['basepath'] . '/include/listing.inc.php');
						$listing = new listing_pages();
						$data = $listing->contact_agent_link();
						break;
					case 'select_language':
						// require_once($config['basepath'] . '/include/multilingual.inc.php');
						// $multilingual = new multilingual();
						// $data = $multilingual->multilingual_select();
						break;
					case 'company_name':
						$data = $config['company_name'];
						break;
					case 'company_location':
						$data = $config['company_location'];
						break;
					case 'company_logo':
						$data = $config['company_logo'];
						break;
					case 'show_vtour':
						if (isset($_GET['listingID'])) {
							require_once($config['basepath'] . '/include/vtour.inc.php');
							$vtour = new vtours();
							$data = $vtour->show_vtour($_GET['listingID'], false);
						} else {
							$data = 'No Listing ID';
						}
						break;
					default:
						if (preg_match("/^addon_(.*?)_.*/", $tag, $addon_name)) {
							include_once($config['basepath'] . '/addons/' . $addon_name[1] . '/addon.inc.php');
							$function_name = $addon_name[1] . '_run_template_user_fields';
							$data = $function_name($tag);
						} else {
							$data = '';
						}
						break;
				}
				// $this->page = eregi_replace('[ ]{'.$tag.'}[ ]', $data, $this->page);
				$this->page = str_replace('{' . $tag . '}', $data, $this->page);
			}
		}
		unset($tags);
		unset($tag);
	}
}
class page_admin extends page {
	function replace_tags($tags = array())
	{
		global $config, $lang;
		require_once($config['basepath'] . '/include/login.inc.php');
		$login = new login();
		$login_status = $login->loginCheck('Agent');
		// First Check for Permission tags
		$this->replace_permission_tags();
		$this->replace_lang_template_tags();
		$this->replace_urls();
		$this->replace_css_template_tags(true);
		if (sizeof($tags) > 0) {
			// Remove tags not found in teh template
			$new_tags = $tags;
			$tags = array();
			foreach($new_tags as $tag) {
				if (strpos($this->page, '{' . $tag . '}') !== false) {
					$tags[] = $tag;
				}
			}
			unset($new_tags);
			foreach($tags as $tag) {
				switch ($tag) {
					case 'select_language':
						// require_once($config['basepath'].'/include/multilingual.inc.php');
						// $multilingual = new multilingual();
						// $data = $multilingual->multilingual_select();
						break;
					case 'version':
						$data = $lang['version'] . ' ' . $config['version'];
						break;
					case 'license_tag':
						$data = "<!--Open-Realty is distributed by Transparent Technologies and is Licensed under the Open-Realty License. See http://www.open-realty.org/license_info.html for more information.-->";
						break;
					case 'company_name':
						$data = $config['company_name'];
						break;
					case 'company_location':
						$data = $config['company_location'];
						break;
					case 'company_logo':
						$data = $config['company_logo'];
						break;
					case 'site_title':
						$data = $config['seo_default_title'];
						break;
					case 'lang_index_home':
						$data = $lang['index_home'];
						break;
					case 'lang_index_admin':
						$data = $lang['index_admin'];
						break;
					case 'lang_index_logout':
						$data = $lang['index_logout'];
						break;
					case 'baseurl':
						$data = $config['baseurl'];
						break;
					case 'general_info':
						require_once($config['basepath'] . '/include/admin.inc.php');
						$admin = new general_admin();
						$data = $admin->general_info();
						break;
					case 'openrealty_links':
						require_once($config['basepath'] . '/include/admin.inc.php');
						$admin = new general_admin();
						$data = $admin->openrealty_links();
						break;
					case 'addon_links':
						// Show Addons
						global $config, $lang;
						$data = '';
						$addons = $this->load_addons();
						require_once($config['basepath'] . '/include/admin.inc.php');
						$admin = new general_admin();
						$addon_links = array();
						foreach ($addons as $addon) {
							$addon_link = array();
							$addon_link = $admin->display_addons($addon);
							if (is_array($addon_link)) {
								foreach ($addon_link as $link) {
									$addon_links[] = $link;
								}
							} else {
								$addon_links[] = $addon_link;
							}
						}
						$current_link = 0;
						$cell_count = 0;
						$link_count = count($addon_links);
						if ($link_count > 0) {
							$data .= '<tr><td colspan="5" align="left">' . $lang['addons'] . '</td></tr>';
						} while ($current_link < $link_count) {
							if ($cell_count == 4) {
								$data .= '</tr>';
								$cell_count = 0;
							}
							if ($cell_count == 0) {
								$data .= '<tr>';
							}
							$data .= '<td style="width:25%; text-align:center;" valign="top">' . $addon_links[$current_link] . '</td>';
							$cell_count++;
							$current_link++;
						} // while
						break;
					case 'lang':
						if (isset($_SESSION["users_lang"]) && $_SESSION["users_lang"] != $config['lang']) {
							$data = $_SESSION["users_lang"];
						} else {
							$data = $config['lang'];
						}
						break;
					case 'user_id':
						$data = $_SESSION['userID'];
						break;
					case 'template_url':
						$data = $config['admin_template_url'];
						break;
					case 'load_js_body':
						require_once($config['basepath'] . '/include/admin.inc.php');
						$admin = new general_admin();
						$data = $admin->load_js_body();
						break;
					case 'load_js':
						$data = $this->load_js();
						break;
					case 'load_js_last':
						global $jscript_last;
						$data = $jscript_last;
						break;
					case 'content':
						$data = $this->replace_admin_actions();
						break;
					default:
						$data = '';
						break;
				}
				// $this->page = preg_replace('/{' . $tag . '}/', $data, $this->page);
				$this->page = str_replace('{' . $tag . '}', $data, $this->page);
			}
		}
	}
	function replace_admin_actions()
	{
		global $config, $lang;
		require_once($config['basepath'] . '/include/login.inc.php');
		$login = new login();
		$login_status = $login->loginCheck('Agent');
		if ($login_status !== true) {
			// Run theese commands even if not logged in.
			$data = '';
			switch ($_GET['action']) {
				case 'send_forgot':
					require_once($config['basepath'] . '/include/login.inc.php');
					$data = login::forgot_password();
					break;
				case 'forgot':
					require_once($config['basepath'] . '/include/login.inc.php');
					$data = login::forgot_password_reset();
					break;
				default:
					$data .= $login_status;
					break;
			}
		} else {
			switch ($_GET['action']) {
				case 'index':
					require_once($config['basepath'] . '/include/admin.inc.php');
					$admin = new general_admin();
					$data = $admin->index_page();
					break;
				case 'edit_page':
					require_once($config['basepath'] . '/include/editor.inc.php');
					$listing = new editor();
					$data = $listing->page_edit();
					break;
				case 'edit_user_images':
					require_once($config['basepath'] . '/include/images.inc.php');
					$images = new image_handler();
					$data = $images->edit_user_images();
					break;
				case 'edit_listing_images':
					require_once($config['basepath'] . '/include/images.inc.php');
					$images = new image_handler();
					$data = $images->edit_listing_images();
					break;
				case 'edit_vtour_images':
					require_once($config['basepath'] . '/include/images.inc.php');
					$images = new image_handler();
					$data = $images->edit_vtour_images();
					break;
				case 'add_listing':
					require_once($config['basepath'] . '/include/listing_editor.inc.php');
					$listing_editor = new listing_editor();
					$data = $listing_editor->add_listing();
					break;
				case 'edit_my_listings':
					require_once($config['basepath'] . '/include/listing_editor.inc.php');
					$listing_editor = new listing_editor();
					$data = $listing_editor->edit_listings();
					break;
				case 'edit_listings':
					require_once($config['basepath'] . '/include/listing_editor.inc.php');
					$listing_editor = new listing_editor();
					$data = $listing_editor->edit_listings(false);
					break;
				case 'configure':
					require_once($config['basepath'] . '/include/controlpanel.inc.php');
					$listing_editor = new configurator();
					$data = $listing_editor->show_configurator();
					break;
				case 'edit_listing_template':
					require_once($config['basepath'] . '/include/template_editor.inc.php');
					$listing = new template_editor();
					$data = $listing->edit_listing_template();
					break;
				case 'edit_listings_template_field_order':
					require_once($config['basepath'] . '/include/template_editor.inc.php');
					$listing = new template_editor();
					$data = $listing->edit_listings_template_field_order();
					break;
				case 'edit_agent_template_field_order':
					require_once($config['basepath'] . '/include/template_editor.inc.php');
					$listing = new template_editor();
					$data = $listing->edit_template_field_order($type = 'agent');
					break;
				case 'edit_member_template_field_order':
					require_once($config['basepath'] . '/include/template_editor.inc.php');
					$listing = new template_editor();
					$data = $listing->edit_template_field_order($type = 'member');
					break;
				case 'edit_agent_template_add_field':
					require_once($config['basepath'] . '/include/template_editor.inc.php');
					$listing = new template_editor();
					$data = $listing->add_user_template_field($type = 'agent');
					break;
				case 'edit_member_template_add_field':
					require_once($config['basepath'] . '/include/template_editor.inc.php');
					$listing = new template_editor();
					$type = 'member';
					$data = $listing->add_user_template_field($type);
					break;
				case 'edit_listing_template_search':
					require_once($config['basepath'] . '/include/template_editor.inc.php');
					$listing = new template_editor();
					$data = $listing->edit_listing_template_search();
					break;
				case 'user_manager':
					require_once($config['basepath'] . '/include/user_manager.inc.php');
					$user_managment = new user_managment();
					$data = $user_managment->show_user_manager();
					break;
				case 'edit_user_template':
					require_once($config['basepath'] . '/include/template_editor.inc.php');
					$listing = new template_editor();
					$data = $listing->edit_user_template();
					break;
				case 'edit_listing_template_add_field':
					require_once($config['basepath'] . '/include/template_editor.inc.php');
					$listing = new template_editor();
					$data = $listing->add_listing_template_field();
					break;
				case 'add_page':
					require_once($config['basepath'] . '/include/editor.inc.php');
					$listing = new editor();
					$data = $listing->add_page();
					break;
				case 'view_log':
					require_once($config['basepath'] . '/include/log.inc.php');
					$data = log::view();
					break;
				case 'show_property_classes':
					require_once($config['basepath'] . '/include/propertyclass.inc.php');
					$data = propertyclass::show_classes();
					break;
				case 'modify_property_class':
					require_once($config['basepath'] . '/include/propertyclass.inc.php');
					$data = propertyclass::modify_property_class();
					break;
				case 'delete_property_class':
					require_once($config['basepath'] . '/include/propertyclass.inc.php');
					$data = propertyclass::delete_property_class();
					break;
				case 'insert_property_class':
					require_once($config['basepath'] . '/include/propertyclass.inc.php');
					$data = propertyclass::insert_property_class();
					break;
				case 'add_listing_property_class':
					require_once($config['basepath'] . '/include/listing_editor.inc.php');
					$listing_editor = new listing_editor();
					$data = $listing_editor->add_listing_logic();
					break;
				default:
					// Handle Addons
					// preg_match("/^addon_(.*)_.*/", $_GET['action'], $addon_name);
					$addon_name = array();
					if (preg_match("/^addon_(.*?)_.*/", $_GET['action'], $addon_name)) {
						include($config['basepath'] . '/addons/' . $addon_name[1] . '/addon.inc.php');
						$function_name = $addon_name[1] . '_run_action_admin_template';
						$data = $function_name();
					}
			}
		}
		return $data;
	}
}

?>