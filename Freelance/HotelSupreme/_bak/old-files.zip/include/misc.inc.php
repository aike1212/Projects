<?php
/**
 * Open-Realty
 *
 * Open-Realty is free software; you can redistribute it and/or modify
 * it under the terms of the Open-Realty License as published by
 * Transparent Technologies; either version 1 of the License, or
 * (at your option) any later version.
 *
 * Open-Realty is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * Open-Realty License for more details.
 * http://www.open-realty.org/license_info.html
 *
 * You should have received a copy of the Open-Realty License
 * along with Open-Realty; if not, write to Transparent Technologies
 * RR1 Box 162C, Kingsley, PA  18826  USA
 *
 * @author Ryan C. Bonham <ryan@transparent-tech.com>
 * @copyright Transparent Technologies 2004
 * @link http://www.open-realty.org Open-Realty Project
 * @link http://www.transparent-tech.com Transparent Technologies
 * @link http://www.open-realty.org/license_info.html Open-Realty License
 */
// Set Error Handling to E_ALL
class misc {
	function or_date_format($date)
	{
		global $config, $conn;
		// $date_format[1] = "mm/dd/yyyy";
		// $date_format[2] = "yyyy/dd/mm";
		// $date_format[3] = "dd/mm/yyyy";
		$new_date = $date;
		switch ($config["date_format"]) {
			case 2:
				preg_match('/(.*?)\/(.*?)\/(.*)/', $date, $matches);
				$new_date = $matches[3] . '/' . $matches[1] . '/' . $matches[1];
				break;
			case 3:
				preg_match('/(.*?)\/(.*?)\/(.*)/', $date, $matches);
				$new_date = $matches[2] . '/' . $matches[1] . '/' . $matches[3];
				break;
		}
		$new_date = strtotime($new_date);
		$new_date = $conn->DBDate($new_date);
		return $new_date;
	}
	function money_formats ($number)
	{
		global $config;
		switch ($config['money_format']) {
			case '2':
				$output = $number . $config['money_sign']; // germany, spain -- 123.456,78
				break;
			case '3':
				$output = $config['money_sign'] . ' ' . $number; // honduras -- 123,456.78
				break;
			default:
				$output = $config['money_sign'] . $number; // usa, uk - $123,345
				break;
		}
		return $output;
	}
	function international_num_format($input, $decimals = 2)
	{
		// internationalizes numbers on the site
		global $config;
		switch ($config['number_format_style']) {
			case '2': // spain, germany
				$output = number_format($input, $decimals, ',', '.');
				break;
			case '3': // estonia
				$output = number_format($input, $decimals, '.', ' ');
				break;
			case '4': // france, norway
				$output = number_format($input, $decimals, ',', ' ');
				break;
			case '5': // switzerland
				$output = number_format($input, $decimals, ",", "'");
				break;
			case '6': // kazahistan
				$output = number_format($input, $decimals, "-", " ");
				break;
			default:
				$output = number_format($input, $decimals, '.', ',');
				break;
		} // end switch
		return $output;
	} // end international_num_format($input)
	function getmicrotime()
	{
		list($usec, $sec) = explode(" ", microtime());
		return ((float)$usec + (float)$sec);
	}
	function make_db_safe ($input) // handles data going into the db
	{
		global $config, $conn;
		if ($config['strip_html'] === "1") {
			$input = strip_tags($input, $config['allowed_html_tags']); // strips out disallowed tags
		}
		$output = $conn->qstr($input, get_magic_quotes_gpc());
		return $output;
	} // end make_db_safe
	function make_db_extra_safe ($input) // handles data going into the db
	{
		global $conn;
		$output = strip_tags($input); // strips out all tags
		$output = ereg_replace (";", "", $output);
		$output = $conn->qstr($output, get_magic_quotes_gpc());
		$output = trim($output);
		return $output;
	} // end make_db_extra_safe
	function make_db_unsafe ($input) // handles data coming out of the db
	{
		$output = stripslashes($input); // strips out slashes
		$output = str_replace("''", "'", $output); // strips out double quotes from m$ db's
		return $output;
	} // end make_db_unsafe
	function log_error($sql)
	{
		// logs SQL errrors for later inspection
		global $config, $lang;
		$message = '';
		$message .= "SQL statement that failed below: " . "\r\n";
		$message .= "---------------------------------------------------------" . "\r\n";
		$message .= $sql . "\r\n";
		$message .= "\r\n"."---------------------------------------------------------" . "\r\n";
		$message .= "\r\n"."ERROR REPORT ".$_SERVER['SERVER_NAME'].": ".date("F j, Y, g:i:s a"). "\r\n";
		$message .= "\r\n"."---------------------------------------------------------" . "\r\n";
		$message .= "SQL ERROR: ".$sql. "\r\n";
		if(isset($_SERVER['SERVER_SOFTWARE'])){
			$message .= "Server Type: ".$_SERVER['SERVER_SOFTWARE']. "\r\n";
		}
		if(isset($_SERVER['REQUEST_METHOD'])){
			$message .= "Request Method: ".$_SERVER['REQUEST_METHOD']. "\r\n";
		}
		if(isset($_SERVER['QUERY_STRING'])){
			$message .= "Query String: ".$_SERVER['QUERY_STRING']. "\r\n";
		}
		if(isset($_SERVER['HTTP_REFERER'])){
			$message .= "Refereer: ".$_SERVER['HTTP_REFERER']. "\r\n";
		}
		if(isset($_SERVER['HTTP_USER_AGENT'])){
			$message .= "User Agent: ".$_SERVER['HTTP_USER_AGENT']. "\r\n";
		}
		if(isset($_SERVER['REQUEST_URI'])){
			$message .= "Request URI: ".$_SERVER['REQUEST_URI']. "\r\n";
		}
		$message .= "POST Variables: ".var_export($_POST,TRUE). "\r\n";
		$message .= "GET Variables: ".var_export($_GET,TRUE). "\r\n";
		$header = "From: " . $config['admin_email'] . " <" . $config['admin_email'] . ">\r\n";
		$header .= "X-Sender: $config[admin_email]\r\n";
		$header .= "Return-Path: $config[admin_email]\r\n";
		mail("$config[admin_email]", "SQL Error http://$_SERVER[SERVER_NAME]", $message, $header);
		die(nl2br($message));
	} // end function log_action
	function next_prev($num_rows, $cur_page, $guidestring = '') // handles multiple page listings
	{
		global $lang, $config;
		$guidestring = '';
		$guidestring_no_action = '';
		$guidestring_with_sort = '';
		// Save GET
		foreach ($_GET as $k => $v) {
			if ($v && $k != 'cur_page' && $k != 'PHPSESSID') {
				if (is_array($v)) {
					foreach ($v as $vitem) {
						$guidestring .= '&amp;' . urlencode("$k") . '[]=' . urlencode("$vitem");
					}
				}else {
					$guidestring .= '&amp;' . urlencode("$k") . '=' . urlencode("$v");
				}
			}
			if ($v && $k != 'cur_page' && $k != 'PHPSESSID' && $k != 'action') {
				if (is_array($v)) {
					foreach ($v as $vitem) {
						$guidestring_no_action .= '&amp;' . urlencode("$k") . '[]=' . urlencode("$vitem");
					}
				}else {
					$guidestring_no_action .= '&amp;' . urlencode("$k") . '=' . urlencode("$v");
				}
			}
		}
		if ($cur_page == "") {
			$cur_page = 0;
		}

		$page_num = $cur_page + 1;
		if ($_GET['action'] == 'view_log')
           {
           $config['listings_per_page'] = '25';
           }
		$total_num_page = ceil($num_rows / $config['listings_per_page']);
		$display = '';

		$display .= '<table class="browse_tool_table" border="0" cellspacing="1" cellpadding="0">';
		$display .= '<tr><td class="browse_tool">';
		if($_GET['action'] == 'view_log') {
			if ($num_rows == 1) {
				$display .= "<span class=\"browse_tool\">$lang[there_is_currently]&nbsp; <strong>$num_rows&nbsp;</strong></span>$lang[log].</td>";
			} else {
				$display .= "<span class=\"browse_tool_num\"><strong>&nbsp;&nbsp;$num_rows&nbsp;</strong></span>$lang[logs_meet_your_search]</td>";
			}
		} else {
			if ($num_rows == 1) {
				$display .= "<span class=\"browse_tool\">$lang[there_is_currently]&nbsp; <strong>$num_rows&nbsp;</strong></span>$lang[listing].</td>";
			}else {
				$display .= "<span class=\"browse_tool_num\"><strong>&nbsp;&nbsp;$num_rows&nbsp;</strong></span>$lang[listings_meet_your_search]</td>";
			}
		}
		$listing_num_min = (($cur_page * $config['listings_per_page']) + 1);

		if ($page_num == $total_num_page) {
			$listing_num_max = $num_rows;
		} else {
			$listing_num_max = $page_num * $config['listings_per_page'];
		}




		$display .= "<td class=\"browse_tool\">&nbsp;&nbsp;$lang[viewing] <span class=\"browse_tool_num\"><strong>&nbsp;&nbsp;$listing_num_min - $listing_num_max&nbsp;&nbsp;</strong></span></td>";

		$prevpage = $cur_page-1;
		$nextpage = $cur_page + 1;
		$next10page = $cur_page + 10;
		$prev10page = $cur_page-10;
		$next_minus10page = $cur_page-10;

		$display .= '<td align="center">
				<table cellpadding="0" cellspacing="0" border="0">
				<tr>
				<td class="browse_tool_button">';
		$checked = login::check_login();
		if ($_GET['action'] == 'searchresults' && $checked === true) {
			$display .= '<a href="index.php?action=save_search' . $guidestring_no_action . '" >' . $lang['save_this_search'] . '</a>';
		}
		$display .= '</td>
				</tr>
				</table>
				</td>
				<td align="center">
				<table cellpadding="0" cellspacing="0" border="0">
				<tr>
				<td class="browse_tool_button">';
		if ($_GET['action'] == 'searchresults') {
			$display .= '<a href="index.php?action=searchpage' . $guidestring_no_action . '" >' . $lang['refine_search'] . '</a>';
		}
		$display .= '</td>
				</tr>
				</table>
				</td>
				</tr>
				<tr>
				<td align="left" colspan="2">
				<table cellpadding="0" cellspacing="1" border="0">
				<tr>
				<td style="height:20px;" class="browse_tool" align="right" >' . $lang['jump_to_page'] . '</td>';
		if ($page_num <= 1) {
			$display .= '<td class="bt_pages_ghost">
					<span class="bt_pages_ghost">&nbsp;&nbsp;&lt;&lt;&nbsp;&nbsp;</span>
					</td>';
		}

		if ($page_num > 1) {
			$display .= '<td class="bt_pages">
					<a href="index.php?cur_page=' . $prevpage . $guidestring . '" class="bt_pages">&nbsp;&nbsp;&lt;&lt;&nbsp;&nbsp;</a>
					</td>';
		} //end if ($page_num > 10)
		// begin 10 page menu selection
		$count = $cur_page;
		$lastnum = $count{strlen($count)-1};
		$count = ($count - $lastnum);

		while ($count < $total_num_page) {
			$disp_count = ($count + 1);
			if ($page_num == $disp_count) {
				// the currently selected page
				$display .= "<td class =\"browse_tool_curpage\" >
						<b>$disp_count</b>
						</td>";
			}else {
				// all other available page cells
				$display .= "<td class=\"bt_pages\" >
						<a href=\"index.php?cur_page=$count$guidestring\" class=\"bt_pages\"><b>$disp_count</b></a>
						</td>";
			}
			$count++;
			// If the last number is a zero, it's divisible by 10 check it...
			if (eregi("0$", $count)) {
				break;
			}
		} // end while ($count <= 10)
		if ($page_num == $total_num_page) {
			$display .= "<td class=\"bt_pages_ghost\" >
					<span class=\"bt_pages_ghost\">&nbsp;&nbsp;&gt;&gt;&nbsp;&nbsp;</span>
					</td>";
		}

		if ($page_num < $total_num_page) {
			$diff = ($total_num_page - $cur_page);
			$display .= "<td class=\"bt_pages\" >
					<a href=\"index.php?cur_page=$nextpage$guidestring\" class=\"bt_pages\">&nbsp;&nbsp;&gt;&gt;&nbsp;&nbsp;</a>
					</td>";
		} //end if
		$display .= '</tr></table></td>';
		// search buttons
		$display .= "<td align=\"center\">	<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\"><tr><td class=\"browse_tool_button\" >";

		if ($page_num > $config['listings_per_page']) { // previous 10 page
				$display .= "<b><a href=\"index.php?cur_page=$prev10page$guidestring\" >$lang[previous_100]</a></b></td>";
		} // end if
		else {
			$display .= "<span class=\"browse_tool_ghost\">$lang[previous_100]</span>
				</td>";
		}
		$display .= " </tr></table></td>";
		// Next 100 button
		$display .= "<td align=\"center\"><table cellpadding=\"0\" cellspacing=\"0\" border=\"0\">
			<tr><td class=\"browse_tool_button\" >";

		if ($cur_page < ($total_num_page - $config['listings_per_page'])) {
			$display .= "<b><a href=\"index.php?cur_page=$next10page$guidestring\" >$lang[next_100]</a></b>
				</td>";
		} //end if ($total_num_page > 10)
		else {
			$display .= "<span class=\"browse_tool_ghost\">$lang[next_100]</span>
				</td>";
		}

		$display .= "</tr></table>";
		// } // end if ($total_num_page != 0)
		$display .= "</td></tr></table>";
		return $display;
	} // end function next_prev
	function send_email($sender, $sender_email, $recipient, $message, $subject)
	{
		global $config, $lang;
		// Make sure data is comming from the site. (Easily faked, but will stop some of the spammers)
		$referers = $config['baseurl'];
		$referers = str_replace('http://', '', $referers);
		$referers = str_replace('https://', '', $referers);
		$referers = str_replace('www.', '', $referers);
		$referers = explode("/", $referers);
		$found = false;
		$temp = explode("/", $_SERVER['HTTP_REFERER']);
		$referer = $temp[2];
		if (eregi ($referers[0], $referer)) {
			$found = true;
		}
		if (!$found) {
			$temp = $lang['email_not_authorized'];
			return $temp;
		}else {
			// First, make sure the form was posted from a browser.
			// For basic web-forms, we don't care about anything
			// other than requests from a browser:
			if (!isset($_SERVER['HTTP_USER_AGENT'])) {
				$temp = $lang['email_not_authorized'];
				return $temp;
			}
			// Attempt to defend against header injections:
			$badStrings = array("Content-Type:",
				"MIME-Version:",
				"Content-Transfer-Encoding:",
				"bcc:",
				"cc:");
			foreach($badStrings as $v2) {
				if (strpos($sender, $v2) !== false) {
					$temp = $lang['email_not_authorized'];
					return $temp;
					exit;
				}
				if (strpos($sender_email, $v2) !== false) {
					$temp = $lang['email_not_authorized'];
					return $temp;
					exit;
				}
				if (strpos($recipient, $v2) !== false) {
					$temp = $lang['email_not_authorized'];
					return $temp;
					exit;
				}
				if (strpos($message, $v2) !== false) {
					$temp = $lang['email_not_authorized'];
					return $temp;;
					exit;
				}
				if (strpos($subject, $v2) !== false) {
					$temp = $lang['email_not_authorized'];
					return $temp;
					exit;
				}
			}
			// validate Sender_email as a Spam check
			$valid = $this->validate_email($sender_email);
			if ($valid) {
				$message = stripslashes($message);
				$subject = stripslashes($subject);
				$header = "From: " . $sender . " <" . $sender_email . ">\r\n";
				$header .= "Return-Path: $config[admin_email]\r\n";
				$header .= "X-Sender: <" . $config["admin_email"] . ">\n";
				$header .= "X-Mailer: Open-Realty " . $config["version"] . " - Installed at " . $config["baseurl"] . "\n";
				$temp = mail($recipient, $subject, $message, $header);
			}else {
				$temp = false;
			}
			return $temp;
		}
	}
	function log_action($log_action)
	{
		$log_action = $this->make_db_safe($log_action);
		// logs user actions
		global $conn, $config;
		if (isset($_SESSION['userID'])) {
			$id = $this->make_db_safe($_SESSION['userID']);
		}else {
			$id = 0;
		}
		$sql = "INSERT INTO " . $config['table_prefix'] . "activitylog (activitylog_log_date, userdb_id, activitylog_action, activitylog_ip_address) VALUES (" . $conn->DBTimeStamp(time()) . ", " . $id . ", $log_action, '$_SERVER[REMOTE_ADDR]')";
		$recordSet = $conn->Execute($sql);
		if ($recordSet === false) {
			$this->log_error($sql);
		}
	} // end function log_action
	function os_type()
	{
		// Get OS
		$test1 = explode("Win32", $_SERVER["SERVER_SOFTWARE"]);
		$test2 = explode("Microsoft", $_SERVER["SERVER_SOFTWARE"]);
		$test3 = explode("BadBlue", $_SERVER["SERVER_SOFTWARE"]);
		// REMOVED EMPTY $OS = ""; else will always catch if the if fails so no point in defining it here.
		if (count($test1) > 1 || count($test2) > 1 || count($test3) > 1) {
			$OS = "Windows";
		}else {
			$OS = "Linux";
		}
		return $OS;
	}
	function validate_email($email)
	{
		// Create the syntactical validation regular expression
		$regexp = "^([_a-z0-9-]+)(\.[_a-z0-9-]+)*@([a-z0-9-]+)(\.[a-z0-9-]+)*(\.[a-z]{2,4})$";
		// Presume that the email is invalid
		$valid = false;
		// Validate the syntax
		if (eregi($regexp, $email)) {
			list($username, $domaintld) = split("@", $email);
			$OS = $this->os_type();
			if ($OS == 'Linux') {
				if (checkdnsrr($domaintld, "ANY")) {
					return true;
				}
			}else {
				return true;
			}
		}
		return $valid;
	}
	// This function is no longer needed. Scripts should no longer call it.
	function clear_cache()
	{
		return true;
	}
function parseDate( $date, $format ) {
	//Supported formats
	//%Y - year as a decimal number including the century
	//%m - month as a decimal number (range 01 to 12)
	//%d - day of the month as a decimal number (range 01 to 31)
	//%H - hour as a decimal number using a 24-hour clock (range 00 to 23)
	//%M - minute as a decimal number
   // Builds up date pattern from the given $format, keeping delimiters in place.

   if( !preg_match_all( "/%([YmdHMp])([^%])*/", $format, $formatTokens, PREG_SET_ORDER ) ) {
       return false;
   }
   foreach( $formatTokens as $formatToken ) {
       $delimiter = preg_quote( $formatToken[2], "/" );
       $datePattern .= "(.*)".$delimiter;
   }
   // Splits up the given $date
   if( !preg_match( "/".$datePattern."/", $date, $dateTokens) ) {
       return false;
   }
   $dateSegments = array();
   for($i = 0; $i < count($formatTokens); $i++) {
       $dateSegments[$formatTokens[$i][1]] = $dateTokens[$i+1];
   }
   // Reformats the given $date into US English date format, suitable for strtotime()
   if( $dateSegments["Y"] && $dateSegments["m"] && $dateSegments["d"] ) {
       $dateReformated = $dateSegments["Y"]."-".$dateSegments["m"]."-".$dateSegments["d"];
   }
   else {
       return false;
   }
   if( $dateSegments["H"] && $dateSegments["M"] ) {
       $dateReformated .= " ".$dateSegments["H"].":".$dateSegments["M"];
   }

   return strtotime( $dateReformated );
}
function sanitize( $value,$length='' )
{
    if( get_magic_quotes_gpc() )
    {
          $value = stripslashes( $value );
    }
	if ($length !='')
	{
	$value=substr($value,0,$length);
    $value = mysql_real_escape_string( $value );
	}
	else
	{
	$value = mysql_real_escape_string( $value );
	}
    return $value;
}
} //End Class misc
?>