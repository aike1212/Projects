<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd" >
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" >
 <body background="http://www.hotelsupreme.com.ph/hs/wallpaper.gif">
 		<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1" />
		<title>{site_title}</title>
		{load_css_style}
		{license_tag}
		{load_js}
		{load_js_body}
		<table style="margin-left:auto; margin-right:auto;" width="735" border="0" cellpadding="0">
			<tr>
 				<td style="width:480px; height:112px;">
				<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="215" height="110" align="middle">
<param name="allowScriptAccess" value="sameDomain" />
<param name="movie" value="{baseurl}/admin/images/logo.swf" /><param name="loop" value="false" /><param name="menu" value="false" /><param name="quality" value="high" /><param name="scale" value="noscale" /><param name="wmode" value="transparent" /><param name="bgcolor" value="#ffffff" /><embed src="{baseurl}/admin/images/logo.swf" loop="false" menu="false" quality="high" scale="noscale" wmode="transparent" bgcolor="#ffffff" width="215" height="110" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
</object>

				
				
				
				</td>
				
				<td>
				  <div style="font-family:'Times New Roman', Times, serif; font-size:9px; width:250px;height:90px; text-align:right; "><a href="http://www.hotelsupreme.com.ph">Hotel Supreme Convention Plaza Integrated CMS</a><br />Developed and Released by: <a href="http://www.i-mediaconcepts.com" >i-Media Concepts Productions</a></div>
					<div style="font-family: Arial, Helvetica, sans-serif; font-size:12px; width:250px; text-align:right; font-weight:bold">VERSION 1.01 </div>
				</td>
			</tr>
			<tr>
				<td colspan="2">
					<div  style="height:15px;width:750px; border-width: 1px 0px 0px 0px; border-style:solid; padding-top:2px; padding-bottom:2px;margin-bottom:10px; font-family: Arial, Helvetica, sans-serif; font-size:8px;">{select_language}<a href="{baseurl}/index.php">{lang_index_home}</a> | <a href="{baseurl}/admin/index.php">{lang_index_admin}</a>{check_agent} | <a href="{baseurl}/admin/index.php?action=log_out">{lang_index_logout}</a>{/check_agent}</div>
				</td>
			</tr>
			
			<tr>
				<td colspan="2" valign="top">
					{content}
				</td>
			</tr>
		</table>
		{load_js_last}
	</body>
</html>