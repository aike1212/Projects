<?php
/**
 * Open-Realty
 *
 * Open-Realty is free software; you can redistribute it and/or modify
 * it under the terms of the Open-Realty License as published by
 * Transparent Technologies; either version 1 of the License, or
 * (at your option) any later version.
 *
 * Open-Realty is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * Open-Realty License for more details.
 * http://www.open-realty.org/license_info.html
 *
 * You should have received a copy of the Open-Realty License
 * along with Open-Realty; if not, write to Transparent Technologies
 * RR1 Box 162C, Kingsley, PA  18826  USA
 *
 * @author Ryan C. Bonham <ryan@transparent-tech.com>
 * @copyright Transparent Technologies 2004
 * @link http://www.open-realty.org Open-Realty Project
 * @link http://www.transparent-tech.com Transparent Technologies
 * @link http://www.open-realty.org/license_info.html Open-Realty License
 */
// Set Error Handling to E_ALL
// error_reporting(E_ALL);
// This Fixes XHTML Validation issues, with PHP
@ini_set('arg_separator.output', '&amp;');
@ini_set('url_rewriter.tags', 'a=href,area=href,frame=src,input=src');
session_start();
header("Cache-control: private"); //IE6 Form Refresh Fix
// Start OutPut Buffer
if (!isset($_GET['printer_friendly'])) {
	$_GET['printer_friendly'] = false;
}
// Check for User Selected Language
if (isset($_POST['select_users_lang'])) {
	session_register('users_lang');
	$_SESSION['users_lang'] = $_POST['select_users_lang'];
}
// Register $config as a global variable
global $config, $conn;
ob_start();
require_once(dirname(__FILE__) . '/../include/common.php');
// Determine which Language File to Use
if (isset($_SESSION["users_lang"]) && $_SESSION["users_lang"] != $config['lang']) {
	include($config['basepath'] . '/include/language/' . $_SESSION['users_lang'] . '/lang.inc.php');
}else {
	// Use Sites Defualt Language
	unset($_SESSION["users_lang"]);
	include($config['basepath'] . '/include/language/' . $config['lang'] . '/lang.inc.php');
}
require_once($config['basepath'] . '/include/login.inc.php');
$login = new login();

if (isset($_GET['action']) && $_GET['action'] == 'log_out') {
	$login->log_out();
}
if (!isset($_GET['action'])) {
	$_GET['action'] = 'index';
}
// Add GetMicroTime Function
require_once($config['basepath'] . '/include/misc.inc.php');
$misc = new misc();
$start_time = $misc->getmicrotime();
require_once($config['basepath'] . '/include/class/template/core.inc.php');
// NEW TEMPLATE SYSTEM
$page = new page_admin();
$page->load_page($config['admin_template_path'] . '/main.html');
$page->replace_tags(array('company_name', 'company_location', 'company_logo', 'site_title', 'license_tag', 'select_language', 'content', 'baseurl', 'template_url', 'load_js_body', 'version', 'lang_index_home', 'lang_index_admin', 'lang_index_logout','user_id', 'load_js', 'load_js_last'));
$page->output_page();
$conn->Close();
// Close Buffer
$buffer = ob_get_contents();
ob_end_clean();
echo $buffer;
// NEW TEMPLATE SYSTEM END
$end_time = $misc->getmicrotime();
$render_time = sprintf('%.16f', $end_time - $start_time);
echo "<!-- This page was generated in $render_time seconds -->";

?>