<?php

$EmailTo = "reservation@hotelsupreme.com.ph";
//$EmailTo = "amaranth1800bc@yahoo.com";
$Subject = "Online Reservation Message";
$name = Trim(stripslashes($_POST['yourname'])); 
$email = Trim(stripslashes($_POST['youraddress'])); 
$arrival = Trim(stripslashes($_POST['yourarrival'])); 
$message = Trim(stripslashes($_POST['yourcomment'])); 

// validation
$validationOK=true;
if (!$validationOK) {
  print "<meta http-equiv=\"refresh\" content=\"0;URL=error.htm\">";
  exit;
}

// prepare email body text
$Body = "";
$Body .= "Name: ";
$Body .= $name;
$Body .= "\n";
$Body .= "Email: ";
$Body .= $email;
$Body .= "\n";
$Body .= "Arrival Date: ";
$Body .= $arrival;
$Body .= "\n";
$Body .= "Message: ";
$Body .= $message;
$Body .= "\n";

// send email 
$success = mail($EmailTo, $Subject, $Body, "From: <$email>");


// redirect to success page 
if ($success){
  print "<meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
}
else{
  print "<meta http-equiv=\"refresh\" content=\"0;URL=error.htm\">";
}
?>

